import React, { useState, useEffect } from 'react';
import { ArrowRight, Lightbulb, ChevronDown } from 'lucide-react';
import { Kid, MathTrack } from '../../types';
import { generateQuestion } from '../../utils/questionGenerator';
import { db } from '../../services/db';
import { ExplanationScreen } from './ExplanationScreen';
import { CoinGuideModal } from './CoinGuideModal';

interface GameScreenProps {
    kid: Kid;
    track: MathTrack;
    questionCount: number;
    onComplete: () => void;
    onResults: (results: { correct: number; total: number; timeSpent: number }) => void;
    onBack: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({ kid, track, questionCount, onComplete, onResults, onBack }) => {
    const [currentLevel, setCurrentLevel] = useState(1);
    const [question, setQuestion] = useState<any>(null);
    const [selectedAnswer, setSelectedAnswer] = useState<any>(null);
    const [gameState, setGameState] = useState<'loading' | 'playing' | 'correct' | 'incorrect'>('loading');
    const [score, setScore] = useState(0);
    const [attempts, setAttempts] = useState(0);
    const [startTime, setStartTime] = useState(Date.now());
    const [totalCorrect, setTotalCorrect] = useState(0);
    const [gameStartTime] = useState(Date.now());
    const [showExplanation, setShowExplanation] = useState(false);
    const [showHelp, setShowHelp] = useState(false);
    const [showCoinGuide, setShowCoinGuide] = useState(false);
    const [currency, setCurrency] = useState<'USD' | 'EUR'>('USD');
    const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);

    const mode = kid.age <= 7 ? 'A' : 'B';

    useEffect(() => {
        startNewQuestion();
    }, []);

    const startNewQuestion = () => {
        const newQuestion = generateQuestion(track.id, currentLevel, kid.difficulty_index, kid.age, currency);
        setQuestion(newQuestion);
        setGameState('playing');
        setSelectedAnswer(null);
        setAttempts(0);
        db.logLevelStart(kid.id, track.id, currentLevel);
        setStartTime(Date.now());
    };

    const handleAnswer = (answer: any) => {
        setSelectedAnswer(answer);
        setAttempts(attempts + 1);

        if (answer === question.correctAnswer) {
            setScore(score + 100);
            setGameState('correct');
            setTotalCorrect(prev => prev + 1);

            const timeSpent = Math.floor((Date.now() - startTime) / 1000);
            db.logLevelComplete(kid.id, track.id, currentLevel, 100, timeSpent);

            // Update coins
            db.addCoins(kid.id, 10);

            setTimeout(() => {
                if (currentLevel < questionCount) {
                    setCurrentLevel(currentLevel + 1);
                    startNewQuestion();
                } else {
                    // Game Over
                    const totalTimeSpent = Math.floor((Date.now() - gameStartTime) / 1000);
                    onResults({
                        correct: totalCorrect + 1, // +1 because state update is async/batched so we add current
                        total: questionCount,
                        timeSpent: totalTimeSpent
                    });
                    onComplete();
                }
            }, 2000);
        } else {
            setGameState('incorrect');
            db.logError(kid.id, track.id, currentLevel, `${question.concept}_error`, kid.difficulty_index, mode);

            // Show explanation after wrong answer
            setTimeout(() => {
                setShowExplanation(true);
            }, 1500);
        }
    };

    const handleTryAgain = () => {
        setShowExplanation(false);
        setGameState('playing');
        setSelectedAnswer(null);
    };

    const handleContinue = () => {
        setShowExplanation(false);
        if (currentLevel < questionCount) {
            setCurrentLevel(currentLevel + 1);
            startNewQuestion();
        } else {
            const totalTimeSpent = Math.floor((Date.now() - gameStartTime) / 1000);
            onResults({
                correct: totalCorrect,
                total: questionCount,
                timeSpent: totalTimeSpent
            });
            onComplete();
        }
    };

    if (!question) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                <div className="text-white text-2xl font-bold">Loading...</div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex flex-col p-4">
            <div className="flex justify-between items-center mb-8">
                <button
                    onClick={onBack}
                    className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
                    aria-label="Exit Game"
                >
                    <ArrowRight className="w-6 h-6 text-gray-600 transform rotate-180" />
                </button>

                <div className="bg-white rounded-full px-6 py-2 shadow-lg">
                    <span className="font-bold text-gray-800">Question {currentLevel}/{questionCount}</span>
                </div>

                <div className="flex gap-2 relative">
                    {/* Currency Selector */}
                    {question?.concept === 'money' && (
                        <div className="relative">
                            <button
                                onClick={() => setShowCurrencyDropdown(!showCurrencyDropdown)}
                                className="bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors px-4 py-2 gap-2 border-2 border-indigo-100"
                                aria-label="Select Currency"
                            >
                                <span className="text-2xl">{currency === 'USD' ? '🇺🇸' : '🇪🇺'}</span>
                                <span className="font-bold text-gray-700 hidden sm:inline">{currency}</span>
                                <ChevronDown className="w-4 h-4 text-gray-400" />
                            </button>

                            {showCurrencyDropdown && (
                                <div className="absolute top-full mt-2 right-0 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-20 min-w-[120px] animate-fade-in">
                                    <button
                                        onClick={() => {
                                            if (currency !== 'USD') {
                                                setCurrency('USD');
                                                // Trigger new question with new currency immediately if desired, 
                                                // but for now let's just update preference for next question or simple re-gen
                                                // Ideally we should regenerate the question if we switch currency mid-game?
                                                // Let's do simple state update for now, user might need to click "Next" or we can force regen.
                                                // Let's force regen for immediate feedback.
                                                const newQ = generateQuestion(track.id, currentLevel, kid.difficulty_index, kid.age, 'USD');
                                                setQuestion(newQ);
                                            }
                                            setShowCurrencyDropdown(false);
                                        }}
                                        className="w-full px-4 py-3 flex items-center gap-3 hover:bg-blue-50 transition-colors text-left"
                                    >
                                        <span className="text-xl">🇺🇸</span>
                                        <span className="font-bold text-gray-700">USD</span>
                                    </button>
                                    <button
                                        onClick={() => {
                                            if (currency !== 'EUR') {
                                                setCurrency('EUR');
                                                const newQ = generateQuestion(track.id, currentLevel, kid.difficulty_index, kid.age, 'EUR');
                                                setQuestion(newQ);
                                            }
                                            setShowCurrencyDropdown(false);
                                        }}
                                        className="w-full px-4 py-3 flex items-center gap-3 hover:bg-blue-50 transition-colors text-left"
                                    >
                                        <span className="text-xl">🇪🇺</span>
                                        <span className="font-bold text-gray-700">EUR</span>
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                    {question.concept === 'money' && (
                        <button
                            onClick={() => setShowCoinGuide(true)}
                            className="bg-green-500 rounded-full shadow-lg flex items-center justify-center hover:scale-105 transition-transform px-4 py-2 gap-2 animate-bounce-subtle"
                            aria-label="Learn Money"
                        >
                            <span className="text-2xl">🪙</span>
                            <span className="text-white font-bold hidden sm:inline">Learn Money</span>
                        </button>
                    )}

                    <button
                        onClick={() => setShowHelp(true)}
                        className="bg-yellow-400 rounded-full shadow-lg flex items-center justify-center hover:bg-yellow-500 transition-colors px-4 py-2 gap-2"
                        aria-label="Help"
                    >
                        <Lightbulb className="w-6 h-6 text-white" />
                        <span className="text-white font-bold hidden sm:inline">Help</span>
                    </button>
                </div>
            </div>

            {/* Modals */}
            {showCoinGuide && <CoinGuideModal onClose={() => setShowCoinGuide(false)} currency={currency} />}

            <div className="flex-1 flex flex-col items-center justify-center">
                <div className="bg-white rounded-3xl p-8 shadow-2xl max-w-2xl w-full">
                    <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">
                        {question.question}
                    </h2>

                    <QuestionVisual question={question} />

                    {/* Answer Options */}
                    <div className="grid grid-cols-2 gap-4 mt-8">
                        {question.options.map((option: any, i: number) => (
                            <button
                                key={i}
                                onClick={() => handleAnswer(option)}
                                disabled={gameState !== 'playing'}
                                className={`h-24 rounded-2xl text-4xl font-bold transition-all transform hover:scale-105 active:scale-95 ${selectedAnswer === option
                                    ? gameState === 'correct'
                                        ? 'bg-green-500 text-white'
                                        : 'bg-red-500 text-white'
                                    : 'bg-gray-100 hover:bg-gray-200'
                                    } disabled:opacity-50`}
                            >
                                {question.concept === 'shapes' ? (
                                    <div className="flex justify-center items-center w-full h-full pointer-events-none">
                                        <div className={`
                                            transition-all duration-300 shadow-sm
                                            ${option === 'circle' ? 'w-16 h-16 rounded-full bg-red-400 border-4 border-red-500' : ''}
                                            ${option === 'square' ? 'w-16 h-16 rounded-xl bg-blue-400 border-4 border-blue-500' : ''}
                                            ${option === 'rectangle' ? 'w-24 h-12 rounded-xl bg-green-400 border-4 border-green-500' : ''}
                                            ${option === 'triangle' ? 'w-0 h-0 border-l-[32px] border-l-transparent border-r-[32px] border-r-transparent border-b-[56px] border-b-yellow-400 filter drop-shadow-sm' : ''}
                                        `} />
                                    </div>
                                ) : (
                                    option
                                )}
                            </button>
                        ))}
                    </div>

                    {/* Feedback */}
                    {gameState === 'correct' && (
                        <div className="mt-6 text-center">
                            <div className="text-6xl mb-2">🎉</div>
                            <p className="text-2xl font-bold text-green-600">Perfect!</p>
                        </div>
                    )}

                    {gameState === 'incorrect' && !showExplanation && (
                        <div className="mt-6 text-center">
                            <div className="text-6xl mb-2">🤔</div>
                            <p className="text-2xl font-bold text-orange-600">Not quite! Let me explain...</p>
                        </div>
                    )}
                </div>
            </div>



            {/* Explanation Modal */}
            {showExplanation && (
                <ExplanationScreen
                    question={question}
                    concept={question.concept}
                    mode={mode}
                    onTryAgain={handleTryAgain}
                    onContinue={handleContinue}
                />
            )}

            {/* Help Modal */}
            {showHelp && (
                <ExplanationScreen
                    question={question}
                    concept={question.concept}
                    mode={mode}
                    onTryAgain={() => setShowHelp(false)}
                    onContinue={() => setShowHelp(false)}
                    isHelpMode={true}
                />
            )}
        </div>
    );
};

const QuestionVisual = ({ question }: { question: any }) => {
    const [removedIndices, setRemovedIndices] = useState<Set<number>>(new Set());

    useEffect(() => {
        setRemovedIndices(new Set());
    }, [question]);

    const toggleRemoved = (index: number) => {
        const newSet = new Set(removedIndices);
        if (newSet.has(index)) {
            newSet.delete(index);
        } else {
            newSet.add(index);
        }
        setRemovedIndices(newSet);
    };

    if (question.concept === 'fractions') {
        if (question.visual.type === 'fraction') {
            const { theme, total, filled } = question.visual;

            if (theme === 'pizza') {
                return (
                    <div className="flex flex-col items-center mb-8">
                        <div className="relative w-64 h-64">
                            {/* Pizza Pan/Crust Background */}
                            <div className="absolute inset-0 rounded-full bg-yellow-600 border-4 border-yellow-700 shadow-xl" />

                            {/* Slices Overlay */}
                            <svg viewBox="0 0 100 100" className="absolute inset-2 w-[calc(100%-1rem)] h-[calc(100%-1rem)] transform -rotate-90">
                                {Array.from({ length: total }).map((_, i) => {
                                    // Calculate slice path
                                    const startAngle = (i * 360) / total;
                                    const endAngle = ((i + 1) * 360) / total;

                                    // Convert polar to cartesian
                                    const x1 = 50 + 50 * Math.cos((startAngle * Math.PI) / 180);
                                    const y1 = 50 + 50 * Math.sin((startAngle * Math.PI) / 180);
                                    const x2 = 50 + 50 * Math.cos((endAngle * Math.PI) / 180);
                                    const y2 = 50 + 50 * Math.sin((endAngle * Math.PI) / 180);

                                    const isFilled = i < filled;
                                    const largeArc = 360 / total > 180 ? 1 : 0;

                                    // Path command: Move to center, Line to start, Arc to end, Line to center
                                    const d = total === 1
                                        ? "M 50,50 m -50,0 a 50,50 0 1,0 100,0 a 50,50 0 1,0 -100,0" // Full circle special case
                                        : `M 50 50 L ${x1} ${y1} A 50 50 0 ${largeArc} 1 ${x2} ${y2} Z`;

                                    return (
                                        <g key={i}>
                                            <path
                                                d={d}
                                                fill={isFilled ? '#FCD34D' : '#FEF3C7'} // Cheese vs Dough
                                                stroke="#B45309"
                                                strokeWidth="0.5"
                                                className="transition-all duration-300"
                                            />
                                            {/* Pepperoni on filled slices */}
                                            {isFilled && (
                                                <circle
                                                    cx={50 + 30 * Math.cos(((startAngle + endAngle) / 2 * Math.PI) / 180)}
                                                    cy={50 + 30 * Math.sin(((startAngle + endAngle) / 2 * Math.PI) / 180)}
                                                    r="4"
                                                    fill="#EF4444"
                                                    opacity="0.8"
                                                />
                                            )}
                                        </g>
                                    );
                                })}
                            </svg>
                        </div>
                        {/* Label */}
                        <div className="mt-4 bg-yellow-100 text-yellow-800 px-4 py-1 rounded-full text-sm font-bold border border-yellow-200">
                            Pizza Party!
                        </div>
                    </div>
                );
            }

            if (theme === 'chocolate') {
                // Determine grid dimensions based on total pieces
                const cols = total <= 4 ? total : Math.ceil(total / 2);

                return (
                    <div className="flex flex-col items-center mb-8">
                        <div className="bg-yellow-900/10 p-4 rounded-xl">
                            <div
                                className="grid gap-1 bg-yellow-800/20 p-1 rounded-lg"
                                style={{
                                    gridTemplateColumns: `repeat(${cols}, 1fr)`
                                }}
                            >
                                {Array.from({ length: total }).map((_, i) => {
                                    const isFilled = i < filled;
                                    return (
                                        <div
                                            key={i}
                                            className={`
                                                w-16 h-24 rounded-md border-2 
                                                flex items-center justify-center relative overflow-hidden shadow-sm
                                                transition-all duration-300
                                                ${isFilled
                                                    ? 'bg-amber-900 border-amber-950'
                                                    : 'bg-amber-100 border-amber-200 opacity-50'
                                                }
                                            `}
                                        >
                                            {isFilled && (
                                                <>
                                                    {/* 3D-ish generic chocolate look using inner shadow/highlight */}
                                                    <div className="absolute inset-2 border border-amber-800/50 rounded-sm opacity-50" />
                                                    <div className="text-amber-950/20 font-bold text-xs select-none">YUM</div>
                                                </>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                        {/* Label */}
                        <div className="mt-4 bg-amber-100 text-amber-900 px-4 py-1 rounded-full text-sm font-bold border border-amber-200">
                            Chocolate Bar
                        </div>
                    </div>
                );
            }
        }

        // Fallback for "old style" string based fractions (or errors)
        if (typeof question.visual === 'string') {
            return (
                <div className="mb-8 text-center text-6xl tracking-widest">
                    {question.visual}
                </div>
            );
        }
    }



    if (question.concept === 'division') {
        const { total, groups } = question.visual;
        const perGroup = Math.floor(total / groups);

        return (
            <div className="flex flex-col items-center mb-8">
                {/* Groups */}
                <div className="flex flex-wrap justify-center gap-6">
                    {Array.from({ length: groups }).map((_, gIndex) => (
                        <div key={gIndex} className="flex flex-col items-center">
                            <div className="bg-blue-50 rounded-2xl p-3 grid grid-cols-2 gap-1 border-2 border-blue-200 min-w-[80px] min-h-[80px] items-center justify-items-center">
                                {Array.from({ length: perGroup }).map((_, i) => (
                                    <div key={i} className="text-2xl">🔵</div>
                                ))}
                            </div>
                            <span className="text-sm text-gray-400 font-bold mt-2">Group {gIndex + 1}</span>
                        </div>
                    ))}
                </div>
                <div className="mt-6 text-gray-500 font-medium text-lg">
                    {total} items ÷ {groups} groups = ?
                </div>
            </div>
        );
    }



    if (question.concept === 'decimals') {
        const num = parseFloat(question.visual.number);
        const whole = Math.floor(num);
        const fraction = Math.round((num - whole) * 100);

        return (
            <div className="flex flex-col items-center mb-8">
                <div className="flex flex-wrap justify-center gap-4 items-end">
                    {/* Whole number blocks */}
                    {Array.from({ length: whole }).map((_, i) => (
                        <div key={`whole-${i}`} className="flex flex-col items-center gap-2">
                            <div className="w-24 h-24 bg-blue-500 border-4 border-blue-600 rounded-lg shadow-md flex items-center justify-center">
                                <span className="text-white font-bold text-3xl">1</span>
                            </div>
                            <span className="text-sm font-bold text-gray-400">1.0</span>
                        </div>
                    ))}

                    {/* Fraction block */}
                    {fraction > 0 && (
                        <div className="flex flex-col items-center gap-2">
                            <div className="w-24 h-24 border-2 border-gray-300 bg-white grid grid-cols-10 grid-rows-10 p-0.5 rounded-lg shadow-inner">
                                {Array.from({ length: 100 }).map((_, i) => (
                                    <div
                                        key={i}
                                        className={`w-full h-full ${i < fraction ? 'bg-blue-400' : 'bg-gray-50'} border-[0.5px] border-white/20`}
                                    />
                                ))}
                            </div>
                            <span className="text-sm font-bold text-gray-400">0.{fraction}</span>
                        </div>
                    )}
                </div>
                <div className="mt-6 text-2xl font-bold tracking-wider text-blue-600">
                    {num}
                </div>
            </div>
        );
    }



    if (question.concept === 'percentages') {
        const { percent } = question.visual;

        return (
            <div className="flex flex-col items-center mb-8">
                <div className="flex flex-col items-center gap-4">
                    <div className="relative">
                        <div className="w-64 h-64 bg-white border-4 border-blue-200 rounded-xl grid grid-cols-10 grid-rows-10 p-1 shadow-inner">
                            {Array.from({ length: 100 }).map((_, i) => (
                                <div
                                    key={i}
                                    className={`w-full h-full border-[0.5px] border-blue-50 rounded-sm transition-all duration-500
                                        ${i < percent
                                            ? 'bg-blue-500 scale-95'
                                            : 'bg-transparent'
                                        }`}
                                />
                            ))}
                        </div>
                        {/* Percentage Label Overlay */}
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <span className="text-6xl font-black text-blue-600 drop-shadow-lg bg-white/80 px-4 py-2 rounded-xl backdrop-blur-sm border-2 border-blue-100">
                                {percent}%
                            </span>
                        </div>
                    </div>

                    <div className="mt-4 text-gray-500 font-medium text-lg text-center">
                        <span className="text-blue-500 font-bold">{percent}</span> out of <span className="font-bold">100</span> squares are blue
                    </div>
                </div>
            </div>
        );
    }

    if (question.concept === 'word_problems') {
        const { start, amount, action, total, groups, day1, day2 } = question.visual;
        const text = question.question.toLowerCase();

        // Determine emoji based on keywords
        let emoji = '⭐️';
        if (text.includes('apple')) emoji = '🍎';
        else if (text.includes('car')) emoji = '🚗';
        else if (text.includes('cookie')) emoji = '🍪';
        else if (text.includes('page')) emoji = '📄';
        else if (text.includes('sweet')) emoji = '🍬';

        // 1. Subtraction: "Gave away"
        if (action === 'gave away' && start !== undefined && amount !== undefined) {
            return (
                <div className="flex flex-col items-center mb-8">
                    <div className="flex flex-wrap justify-center gap-4 max-w-md">
                        {Array.from({ length: start }).map((_, i) => {
                            // The last 'amount' items are the ones given away
                            const isGivenAway = i >= (start - amount);
                            return (
                                <div key={i} className="relative text-5xl transition-all duration-500">
                                    <span className={isGivenAway ? "opacity-40 grayscale" : ""}>{emoji}</span>
                                    {isGivenAway && (
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <div className="w-full h-1 bg-red-500 transform rotate-45" />
                                            <div className="w-full h-1 bg-red-500 transform -rotate-45" />
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                    <div className="mt-4 text-gray-500 font-medium">
                        {start} {emoji} - {amount} {emoji} given away
                    </div>
                </div>
            );
        }

        // 2. Addition: "Got" (more)
        if (action === 'got' && start !== undefined && amount !== undefined) {
            return (
                <div className="flex flex-col items-center mb-8">
                    <div className="flex items-center gap-4">
                        {/* Start Items */}
                        <div className="flex flex-wrap justify-center gap-2 max-w-[150px] p-2 bg-blue-50 rounded-lg border border-blue-100">
                            {Array.from({ length: start }).map((_, i) => (
                                <div key={`start-${i}`} className="text-4xl">{emoji}</div>
                            ))}
                        </div>

                        <div className="text-3xl font-bold text-gray-400">+</div>

                        {/* Additional Items */}
                        <div className="flex flex-wrap justify-center gap-2 max-w-[150px] p-2 bg-green-50 rounded-lg border border-green-100 relative">
                            {Array.from({ length: amount }).map((_, i) => (
                                <div key={`more-${i}`} className="text-4xl animate-bounce-subtle" style={{ animationDelay: `${i * 100}ms` }}>{emoji}</div>
                            ))}
                            <span className="absolute -top-3 -right-3 bg-green-500 text-white text-xs px-2 py-0.5 rounded-full font-bold">New!</span>
                        </div>
                    </div>
                </div>
            );
        }

        // 3. Division: "Share equally"
        if (action === 'share equally' && total !== undefined && groups !== undefined) {
            const perGroup = Math.floor(total / groups);
            return (
                <div className="flex flex-col items-center mb-8">
                    {/* Groups */}
                    <div className="flex flex-wrap justify-center gap-6">
                        {Array.from({ length: groups }).map((_, gIndex) => (
                            <div key={gIndex} className="flex flex-col items-center">
                                <div className="bg-gray-100 rounded-2xl p-3 grid grid-cols-2 gap-1 border-2 border-gray-200 min-w-[80px] min-h-[80px] items-center justify-items-center">
                                    {Array.from({ length: perGroup }).map((_, i) => (
                                        <div key={i} className="text-2xl">{emoji}</div>
                                    ))}
                                </div>
                                <span className="text-sm text-gray-400 font-bold mt-2">Friend {gIndex + 1}</span>
                            </div>
                        ))}
                    </div>
                </div>
            );
        }

        // 4. Addition: "Total" (Day 1 + Day 2)
        if (action === 'total' && day1 !== undefined && day2 !== undefined) {
            return (
                <div className="flex flex-col items-center mb-8">
                    <div className="flex items-end gap-2">
                        {/* Stacked visualization maybe? Or just side by side */}
                        <div className="flex flex-col items-center gap-2">
                            <span className="text-sm font-bold text-gray-400">Day 1</span>
                            <div className="flex flex-wrap justify-center gap-2 max-w-[120px]">
                                {Array.from({ length: day1 }).map((_, i) => <div key={i} className="text-3xl">{emoji}</div>)}
                            </div>
                        </div>

                        <div className="h-16 w-px bg-gray-300 mx-2" />

                        <div className="flex flex-col items-center gap-2">
                            <span className="text-sm font-bold text-gray-400">Day 2</span>
                            <div className="flex flex-wrap justify-center gap-2 max-w-[120px]">
                                {Array.from({ length: day2 }).map((_, i) => <div key={i} className="text-3xl">{emoji}</div>)}
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
    }

    if (question.concept === 'counting') {
        const totalItems = question.visual.length;

        // Group items into chunks of 10 (Ten Frames concept)
        const groups = [];
        for (let i = 0; i < totalItems; i += 10) {
            groups.push(question.visual.slice(i, i + 10));
        }

        // Dynamic sizing based on total count to ensure everything fits well
        const getItemSize = () => {
            if (totalItems > 50) return 'text-2xl';
            if (totalItems > 20) return 'text-3xl';
            return 'text-5xl';
        };

        const itemSize = getItemSize();

        return (
            <div className="flex flex-col items-center gap-4 mb-8 max-w-4xl mx-auto">
                <div className="flex flex-wrap justify-center gap-6">
                    {groups.map((group, groupIndex) => (
                        <div
                            key={groupIndex}
                            className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-xl p-2 flex flex-wrap gap-1 justify-center w-fit max-w-[300px]"
                        >
                            {group.map((obj: string, i: number) => (
                                <div key={i} className={`${itemSize} transition-all hover:scale-110`}>
                                    {obj}
                                </div>
                            ))}
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    if (question.concept === 'addition' && question.visual.groupA) {
        const countA = question.visual.groupA.length;
        const countB = question.visual.groupB.length;

        // Use Base-10 Block Visualization for larger numbers (Age 8-10 logic)
        if (countA > 10 || countB > 10) {

            const renderBase10 = (count: number) => {
                const tens = Math.floor(count / 10);
                const ones = count % 10;
                return (
                    <div className="flex items-end gap-2">
                        {/* Tens Rods */}
                        {tens > 0 && (
                            <div className="flex gap-1">
                                {Array.from({ length: tens }).map((_, i) => (
                                    <div key={`ten-${i}`} className="w-4 h-16 bg-blue-500 rounded-sm border border-blue-600 flex flex-col justify-between py-0.5">
                                        {Array.from({ length: 9 }).map((_, j) => (
                                            <div key={j} className="h-px w-full bg-blue-400/50" />
                                        ))}
                                    </div>
                                ))}
                            </div>
                        )}

                        {/* Ones Cubes */}
                        {ones > 0 && (
                            <div className="grid grid-cols-2 gap-0.5 content-end w-8">
                                {Array.from({ length: ones }).map((_, i) => (
                                    <div key={`one-${i}`} className="w-3.5 h-3.5 bg-yellow-400 rounded-sm border border-yellow-500" />
                                ))}
                            </div>
                        )}
                    </div>
                );
            };

            return (
                <div className="flex flex-col items-center mb-8 bg-gray-50 p-6 rounded-2xl border-2 border-gray-100">
                    <div className="grid grid-cols-[auto_1fr] gap-x-8 gap-y-4 items-center">
                        {/* First Number */}
                        <div className="text-5xl font-bold text-gray-700 text-right font-mono tracking-widest">{countA}</div>
                        <div className="pl-4">{renderBase10(countA)}</div>

                        {/* Second Number with Plus */}
                        <div className="relative text-5xl font-bold text-gray-700 text-right font-mono tracking-widest flex justify-end items-center gap-4">
                            <span className="absolute -left-8 text-gray-400">+</span>
                            {countB}
                        </div>
                        <div className="pl-4">{renderBase10(countB)}</div>
                    </div>

                    {/* Divider Line */}
                    <div className="w-64 h-1 bg-gray-800 my-4 rounded-full" />

                    {/* Question Mark */}
                    <div className="text-6xl font-bold text-blue-600 animate-pulse">?</div>
                </div>
            );
        }

        // Fallback to simple dot groups for small numbers (< 10)
        return (
            <div className="flex justify-center items-center gap-6 mb-8">
                <div className="text-center">
                    <div className="flex gap-2 flex-wrap justify-center max-w-xs">
                        {question.visual.groupA.map((obj: string, i: number) => (
                            <div key={i} className="text-4xl">{obj}</div>
                        ))}
                    </div>
                </div>
                <div className="text-3xl font-bold text-gray-600">+</div>
                <div className="text-center">
                    <div className="flex gap-2 flex-wrap justify-center max-w-xs">
                        {question.visual.groupB.map((obj: string, i: number) => (
                            <div key={i} className="text-4xl">{obj}</div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }



    if (question.concept === 'multiplication' && question.visual.groups) {
        return (
            <div className="mb-8">
                <div className="space-y-3">
                    {Array(question.visual.groups).fill(null).map((_, groupIndex) => (
                        <div key={groupIndex} className="flex justify-center gap-2">
                            {Array(question.visual.perGroup).fill('🔷').map((obj, i) => (
                                <div key={i} className="text-3xl">{obj}</div>
                            ))}
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    if (question.concept === 'number_bonds' && question.visual.total) {
        return (
            <div className="flex flex-col items-center mb-12 relative">
                {/* Total Circle (Top) */}
                <div className="w-32 h-32 rounded-full border-4 border-purple-500 flex items-center justify-center bg-purple-50 relative z-10 mb-16">
                    <div className="flex flex-wrap justify-center gap-1 p-2">
                        {question.visual.total.map((obj: string, i: number) => (
                            <span key={i} className="text-xl">{obj}</span>
                        ))}
                    </div>
                    {/* Connection Lines */}
                    <div className="absolute -bottom-16 left-1/2 w-1 h-16 bg-purple-300 transform -translate-x-1/2 -rotate-45 origin-top"></div>
                    <div className="absolute -bottom-16 left-1/2 w-1 h-16 bg-purple-300 transform -translate-x-1/2 rotate-45 origin-top"></div>
                </div>

                {/* Parts Circles (Bottom) */}
                <div className="flex gap-16">
                    <div className="w-24 h-24 rounded-full border-4 border-blue-500 flex items-center justify-center bg-blue-50 relative z-10">
                        <div className="flex flex-wrap justify-center gap-1 p-2">
                            {question.visual.part1.map((obj: string, i: number) => (
                                <span key={i} className="text-lg">{obj}</span>
                            ))}
                        </div>
                    </div>

                    <div className="w-24 h-24 rounded-full border-4 border-blue-500 flex items-center justify-center bg-blue-50 relative z-10">
                        {typeof question.visual.part2 === 'number' ? (
                            <span className="text-4xl text-blue-300 font-bold">?</span>
                        ) : (
                            <div className="flex flex-wrap justify-center gap-1 p-2">
                                {/* If it was an array it would render here */}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    if (question.concept === 'data') {
        const data = question.visual as Record<string, number>;
        const maxVal = Math.max(...Object.values(data));
        // Ensure scale is at least 5 or slightly larger than max for nice visual headroom
        const scaleMax = maxVal < 5 ? 5 : Math.ceil(maxVal / 2) * 2;

        return (
            <div className="flex items-start justify-center mb-8 w-full max-w-lg mx-auto gap-3">
                {/* Y-Axis */}
                <div className="flex flex-col-reverse justify-between h-64 py-0 text-gray-400 text-sm font-bold text-right w-6">
                    {Array.from({ length: scaleMax + 1 }).map((_, i) => (
                        <span key={i} className="leading-none transform translate-y-1/2">{i}</span>
                    ))}
                </div>

                {/* Chart Area */}
                <div className="flex-1 flex flex-col">
                    {/* Grid & Bars Container */}
                    <div className="relative h-64 border-l-2 border-b-2 border-gray-300 w-full bg-white bg-opacity-50 rounded-tr-lg">
                        {/* Grid Lines */}
                        <div className="absolute inset-x-0 bottom-0 top-0 flex flex-col-reverse justify-between pointer-events-none z-0">
                            {Array.from({ length: scaleMax + 1 }).map((_, i) => (
                                <div
                                    key={i}
                                    className={`w-full border-t border-gray-100 ${i === 0 ? 'border-transparent' : 'border-dashed'}`}
                                    style={{ height: '0px' }}
                                />
                            ))}
                        </div>

                        {/* Bars */}
                        <div className="absolute inset-0 flex items-end justify-around px-2 z-10">
                            {Object.entries(data).map(([label, value]) => (
                                <div key={label} className="flex flex-col items-center w-full px-1 sm:px-3 h-full justify-end group">
                                    <div
                                        className="w-full bg-blue-500 rounded-t-sm sm:rounded-t-md transition-all relative group-hover:bg-blue-600 shadow-sm"
                                        style={{ height: `${(value / scaleMax) * 100}%` }}
                                    >
                                        <div className="absolute -top-7 left-1/2 transform -translate-x-1/2 font-bold text-blue-600 bg-white px-2 py-0.5 rounded shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                                            {value}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* X-Axis Labels */}
                    <div className="flex justify-around px-2 mt-2">
                        {Object.keys(data).map((label) => (
                            <div key={label} className="flex-1 text-center text-xs sm:text-sm font-bold text-gray-600 capitalize truncate px-1">
                                {label}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    if (question.concept === 'subtraction' && question.visual.start) {
        const { start, takeAway } = question.visual;
        const countRemoved = removedIndices.size;
        const currentRemaining = start.length - countRemoved;

        return (
            <div className="flex flex-col items-center mb-8">
                <div className="mb-4 text-xl font-bold text-orange-600 animate-pulse">
                    Tap {takeAway} items to take them away!
                </div>
                <div className="flex flex-wrap justify-center gap-4 max-w-lg cursor-pointer">
                    {start.map((item: string, i: number) => {
                        const isTakenAway = removedIndices.has(i);
                        return (
                            <div
                                key={i}
                                onClick={() => toggleRemoved(i)}
                                className={`
                                    text-5xl transition-all duration-300 select-none
                                    ${isTakenAway ? 'opacity-30 scale-90 grayscale relative' : 'scale-100 hover:scale-110 active:scale-95 animate-bounce'}
                                `}
                                style={{ animationDelay: `${i * 0.1}s` }}
                            >
                                {item}
                                {isTakenAway && (
                                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                        <div className="w-full h-1 bg-red-500 transform rotate-45 rounded-full" />
                                        <div className="w-full h-1 bg-red-500 transform -rotate-45 rounded-full absolute" />
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
                <div className="mt-4 text-gray-500 font-medium text-xl transition-all">
                    {currentRemaining} left
                    {countRemoved === takeAway && <span className="ml-2 text-green-500 font-bold">✓ Great Job!</span>}
                </div>
            </div>
        );
    }

    if (question.concept === 'time' && question.visual.hour !== undefined) {
        const { hour, minute } = question.visual;
        const minuteRotation = minute * 6; // 360 / 60 = 6 degrees per minute
        const hourRotation = (hour % 12) * 30 + (minute / 2); // 360 / 12 = 30 deg per hour + 0.5 deg per minute

        return (
            <div className="flex flex-col items-center mb-8">
                <div className="relative w-64 h-64 rounded-full border-8 border-gray-800 bg-white shadow-xl flex items-center justify-center">

                    {/* Minute Numbers (Inner Ring) */}
                    {[...Array(12)].map((_, i) => {
                        const val = (i + 1) * 5;
                        return (
                            <div
                                key={`min-${i}`}
                                className="absolute text-xs font-bold text-blue-400"
                                style={{
                                    transform: `rotate(${(i + 1) * 30}deg) translateY(-60px) rotate(-${(i + 1) * 30}deg)`
                                }}
                            >
                                {val}
                            </div>
                        );
                    })}

                    {/* Hour Numbers (Outer Ring) */}
                    {[...Array(12)].map((_, i) => (
                        <div
                            key={`hour-${i}`}
                            className="absolute text-xl font-bold text-gray-700"
                            style={{
                                transform: `rotate(${(i + 1) * 30}deg) translateY(-90px) rotate(-${(i + 1) * 30}deg)`
                            }}
                        >
                            {i + 1}
                        </div>
                    ))}

                    {/* Ticks for minutes */}
                    {[...Array(60)].map((_, i) => (
                        <div
                            key={`tick-${i}`}
                            className={`absolute bg-gray-300 ${i % 5 === 0 ? 'w-1 h-3' : 'w-0.5 h-1.5'}`}
                            style={{
                                top: '4px',
                                transformOrigin: '50% 120px', // Center of clock relative to top edge
                                transform: `rotate(${i * 6}deg)`
                            }}
                        />
                    ))}

                    {/* Hour Hand */}
                    <div
                        className="absolute w-2 h-16 bg-black rounded-full origin-bottom"
                        style={{
                            bottom: '50%',
                            left: 'calc(50% - 4px)',
                            transform: `rotate(${hourRotation}deg)`
                        }}
                    />

                    {/* Minute Hand */}
                    <div
                        className="absolute w-1.5 h-24 bg-blue-500 rounded-full origin-bottom"
                        style={{
                            bottom: '50%',
                            left: 'calc(50% - 3px)',
                            transform: `rotate(${minuteRotation}deg)`
                        }}
                    />

                    {/* Center Dot */}
                    <div className="absolute w-4 h-4 bg-red-500 rounded-full border-2 border-white z-10" />
                </div>
            </div>
        );
    }



    if (question.concept === 'place_value' && question.visual.tens !== undefined) {
        return (
            <div className="flex flex-col items-center mb-8">
                <div className="flex items-end gap-8 p-6 bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
                    {/* Tens Group */}
                    <div className="flex flex-col items-center gap-2">
                        <div className="flex gap-2">
                            {Array.from({ length: question.visual.tens }).map((_, i) => (
                                <div key={`ten-${i}`} className="w-4 h-32 bg-indigo-500 rounded-sm border border-indigo-600 flex flex-col justify-between py-1">
                                    {/* Visual lines to look like a rod of 10 */}
                                    {Array.from({ length: 9 }).map((_, j) => (
                                        <div key={j} className="h-px w-full bg-indigo-400/50" />
                                    ))}
                                </div>
                            ))}
                        </div>
                        <span className="font-bold text-gray-500 text-sm uppercase tracking-wider">Tens ({question.visual.tens})</span>
                    </div>

                    {/* Ones Group */}
                    <div className="flex flex-col items-center gap-2">
                        <div className="grid grid-cols-5 gap-1 content-end" style={{ height: '8rem' /* Match rod height broadly */ }}>
                            {Array.from({ length: question.visual.ones }).map((_, i) => (
                                <div key={`one-${i}`} className="w-4 h-4 bg-yellow-400 rounded-sm border border-yellow-500" />
                            ))}
                        </div>
                        <span className="font-bold text-gray-500 text-sm uppercase tracking-wider">Ones ({question.visual.ones})</span>
                    </div>
                </div>
                <div className="mt-4 text-xl font-bold text-gray-700">
                    {question.visual.tens} Tens + {question.visual.ones} Ones = ?
                </div>
            </div>
        );
    }

    if (question.concept === 'algebra' || question.concept === 'patterns' || question.concept === 'skip_counting') {
        const sequence = Array.isArray(question.visual) ? question.visual : [];
        return (
            <div className="flex flex-wrap justify-center gap-4 mb-8">
                {sequence.map((item: string | number, i: number) => {
                    const isMissing = item === '?' || item === '__';
                    return (
                        <div
                            key={i}
                            className={`
                                w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-bold shadow-sm border-b-4 transition-all
                                ${isMissing
                                    ? 'bg-gray-100 border-gray-200 text-gray-400 animate-pulse'
                                    : 'bg-white border-blue-200 text-blue-600'
                                }
                            `}
                        >
                            {isMissing ? '?' : item}
                        </div>
                    )
                })}
            </div>
        );
    }

    if (question.concept === 'shapes') {
        if (typeof question.visual === 'string') {
            const shape = question.visual.toLowerCase();
            return (
                <div className="flex justify-center mb-8">
                    <div className={`
                        w-48 h-48 transition-all duration-500
                        ${shape.includes('circle') ? 'rounded-full bg-red-400' : ''}
                        ${shape.includes('square') ? 'bg-blue-400 rounded-lg' : ''}
                        ${shape.includes('rectangle') ? 'w-64 bg-green-400 rounded-lg' : ''}
                        ${shape.includes('triangle') ? 'w-0 h-0 border-l-[100px] border-l-transparent border-r-[100px] border-r-transparent border-b-[174px] border-b-yellow-400' : ''}
                        ${/* Fallback */ !['circle', 'square', 'rectangle', 'triangle'].some(s => shape.includes(s)) ? 'bg-purple-200 rounded-xl flex items-center justify-center' : ''}
                     `}>
                        {!['circle', 'square', 'rectangle', 'triangle'].some(s => shape.includes(s)) && (
                            <span className="text-2xl font-bold text-purple-700 capitalize">{shape}</span>
                        )}
                    </div>
                </div>
            )
        }
    }

    if (question.concept === 'money') {
        const { coin, count } = question.visual;
        // fallback for array (legacy) or object
        const coinType = coin || 'coin';
        const numCoins = count || (Array.isArray(question.visual) ? question.visual.length : 1);


        const getCoinStyle = (c: string) => {
            const type = c.toLowerCase();

            // USD
            if (type.includes('quarter')) return {
                bg: 'bg-gradient-to-br from-gray-200 to-gray-400',
                size: 'w-24 h-24',
                text: '25¢',
                border: 'border-gray-300',
                inner: 'border-dashed border-gray-400'
            };
            if (type.includes('dime')) return {
                bg: 'bg-gradient-to-br from-gray-200 to-gray-300',
                size: 'w-16 h-16',
                text: '10¢',
                border: 'border-gray-300',
                inner: 'border-gray-400'
            };
            if (type.includes('nickel')) return {
                bg: 'bg-gradient-to-br from-gray-300 to-gray-400',
                size: 'w-20 h-20',
                text: '5¢',
                border: 'border-gray-400',
                inner: 'border-gray-500'
            };
            if (type.includes('penny')) return {
                bg: 'bg-gradient-to-br from-amber-600 to-amber-700',
                size: 'w-16 h-16',
                text: '1¢',
                textColor: 'text-amber-100',
                border: 'border-amber-800',
                inner: 'border-amber-900'
            };

            // EURO
            // Copper coins (1c, 2c, 5c)
            if (['1 cent', '2 cent', '5 cent'].some(v => type.startsWith(v))) {
                const value = type.split(' ')[0];
                return {
                    bg: 'bg-gradient-to-br from-orange-400 to-red-400',
                    size: value === '5' ? 'w-20 h-20' : value === '2' ? 'w-18 h-18' : 'w-16 h-16',
                    text: `${value}c`,
                    textColor: 'text-white',
                    border: 'border-red-500',
                    inner: 'border-red-300'
                };
            }
            // Nordic Gold coins (10c, 20c, 50c)
            if (['10 cent', '20 cent', '50 cent'].some(v => type.startsWith(v))) {
                const value = type.split(' ')[0];
                const is20 = value === '20';
                return {
                    bg: 'bg-gradient-to-br from-yellow-300 via-yellow-400 to-yellow-600',
                    size: value === '50' ? 'w-24 h-24' : value === '20' ? 'w-22 h-22' : 'w-20 h-20',
                    text: `${value}c`,
                    textColor: 'text-yellow-900',
                    border: 'border-yellow-600',
                    inner: 'border-yellow-200',
                    customClass: is20 ? 'rounded-[30px]' : 'rounded-full' // Slight attempt at flower shape for 20c
                };
            }

            return { bg: 'bg-gray-100', size: 'w-20 h-20', text: '?', border: 'border-gray-300' };
        };

        const style = getCoinStyle(coinType);

        return (
            <div className="flex flex-col items-center mb-8">
                <div className="flex flex-wrap justify-center gap-4 mb-4">
                    {Array(numCoins).fill(null).map((_, i) => (
                        <div
                            key={i}
                            className={`
                                ${style.size} ${style.bg} ${style.customClass || 'rounded-full'} border-4 ${style.border} 
                                flex items-center justify-center shadow-lg transform hover:-translate-y-1 transition-transform relative
                            `}
                        >
                            <div className={`absolute inset-1 ${style.customClass || 'rounded-full'} border-2 ${style.inner} opacity-50`}></div>
                            <span className={`font-bold text-xl md:text-2xl ${style.textColor || 'text-gray-700'} z-10`}>
                                {style.text}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    if (question.concept === 'comparison') {
        const left = question.visual.groupA || question.visual.left;
        const right = question.visual.groupB || question.visual.right;

        if (left && right) {
            return (
                <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-12 mb-8">
                    {/* Group A */}
                    <div className="flex-1 min-w-[200px] p-6 bg-blue-50 rounded-2xl border-4 border-blue-200 text-center relative">
                        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-4 py-1 rounded-full font-bold text-sm uppercase tracking-wider shadow-sm">
                            Group A
                        </div>
                        <div className="mt-2 flex flex-wrap justify-center gap-2">
                            {Array.isArray(left) ? (
                                left.length > 15 ? (
                                    <>
                                        {left.slice(0, 10).map((item: any, i: number) => (
                                            <div key={i} className="text-4xl animate-bounce" style={{ animationDelay: `${i * 0.1}s` }}>{item}</div>
                                        ))}
                                        <div className="text-2xl font-bold text-blue-400 self-center">+{left.length - 10}</div>
                                    </>
                                ) : (
                                    left.map((item: any, i: number) => (
                                        <div key={i} className="text-4xl transform hover:scale-125 transition-transform cursor-pointer">{item}</div>
                                    ))
                                )
                            ) : (
                                <div className="text-6xl font-bold text-blue-500">{left}</div>
                            )}
                        </div>
                    </div>

                    <div className="text-4xl font-black text-gray-300">VS</div>

                    {/* Group B */}
                    <div className="flex-1 min-w-[200px] p-6 bg-purple-50 rounded-2xl border-4 border-purple-200 text-center relative">
                        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-purple-500 text-white px-4 py-1 rounded-full font-bold text-sm uppercase tracking-wider shadow-sm">
                            Group B
                        </div>
                        <div className="mt-2 flex flex-wrap justify-center gap-2">
                            {Array.isArray(right) ? (
                                right.length > 15 ? (
                                    <>
                                        {right.slice(0, 10).map((item: any, i: number) => (
                                            <div key={i} className="text-4xl animate-bounce" style={{ animationDelay: `${i * 0.1}s` }}>{item}</div>
                                        ))}
                                        <div className="text-2xl font-bold text-purple-400 self-center">+{right.length - 10}</div>
                                    </>
                                ) : (
                                    right.map((item: any, i: number) => (
                                        <div key={i} className="text-4xl transform hover:scale-125 transition-transform cursor-pointer">{item}</div>
                                    ))
                                )
                            ) : (
                                <div className="text-6xl font-bold text-purple-500">{right}</div>
                            )}
                        </div>
                    </div>
                </div>
            )
        }
    }

    if (question.concept === 'measurement') {
        const { unit, type, item } = question.visual;
        const isLength = ['inches', 'feet', 'yards'].includes(unit);
        const isWeight = ['ounces', 'pounds', 'tons'].includes(unit);

        // Object Estimation (e.g., Pencil length)
        if (type === 'object') {
            return (
                <div className="flex flex-col items-center mb-8">
                    <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-indigo-100 max-w-md w-full relative overflow-hidden">
                        <div className="flex flex-col items-center gap-6">
                            {/* Object Visual */}
                            <div className="w-32 h-32 bg-blue-50 rounded-full flex items-center justify-center text-7xl shadow-inner mb-2 relative">
                                {item === 'pencil' && <span>✏️</span>}
                                {!item && <span>📏</span>}
                                {/* Dotted line indicating length */}
                                <div className="absolute -bottom-4 w-full flex justify-between text-xs text-gray-400 font-mono">
                                    <span>|</span>
                                    <span>? {unit}</span>
                                    <span>|</span>
                                </div>
                            </div>

                            {/* Ruler Visual */}
                            <div className="w-full h-14 bg-yellow-300 border-2 border-yellow-500 rounded-md shadow-sm relative flex items-end overflow-hidden">
                                {[...Array(12)].map((_, i) => (
                                    <div key={i} className="flex-1 h-3/4 border-r border-yellow-600/50 flex justify-end flex-col items-center">
                                        <div className="w-0.5 h-2 bg-yellow-700/40"></div>
                                        {i % 2 === 0 && <span className="text-[10px] text-yellow-800 font-bold mb-1">{i}</span>}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            );
        }

        // Conversion Visual (Standard)
        return (
            <div className="flex flex-col items-center mb-8">
                <div className="bg-white p-8 rounded-2xl shadow-lg border-2 border-indigo-100 max-w-md w-full relative overflow-hidden">
                    {/* Background Pattern */}
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-400 to-purple-400"></div>

                    <div className="flex flex-col items-center gap-6">
                        {/* Icon/Graphic Area */}
                        <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center text-6xl shadow-inner relative">
                            {isLength && <span className="transform -rotate-45">📏</span>}
                            {isWeight && <span>⚖️</span>}
                            {!isLength && !isWeight && <span>📏</span>}

                            {/* Decorative particles */}
                            <div className="absolute top-0 right-0 w-3 h-3 bg-yellow-400 rounded-full animate-ping opacity-75"></div>
                        </div>

                        {/* Conversion Visual */}
                        <div className="flex items-center gap-4 text-gray-700 font-bold text-xl md:text-2xl">
                            <div className="bg-gray-100 px-4 py-2 rounded-lg border border-gray-200">
                                1 {isLength ? (unit === 'inches' ? 'foot' : unit === 'feet' ? 'yard' : 'unit') : (unit === 'ounces' ? 'pound' : 'unit')}
                            </div>
                            <div className="text-indigo-400 text-3xl">➜</div>
                            <div className="bg-indigo-50 px-4 py-2 rounded-lg border border-indigo-200 text-indigo-700 flex items-center gap-2">
                                <span className="text-3xl">?</span>
                                <span className="text-lg opacity-70">{unit}</span>
                            </div>
                        </div>

                        {/* Visual Aid (Ruler or Scale hint) */}
                        {isLength && (
                            <div className="w-full h-12 bg-yellow-200 border-2 border-yellow-400 rounded-md relative mt-2 shadow-sm flex items-end overflow-hidden">
                                {[...Array(12)].map((_, i) => (
                                    <div key={i} className="flex-1 h-1/2 border-r border-yellow-500/50 flex justify-end flex-col items-center">
                                        <div className="w-0.5 h-2 bg-yellow-600/30"></div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    if (Array.isArray(question.visual)) {
        return <div className="text-center text-4xl mb-6">{question.visual.join(' ')}</div>;
    }

    if (typeof question.visual === 'object' && question.visual !== null) {
        return <div className="text-center text-xl mb-6"><pre>{JSON.stringify(question.visual, null, 2)}</pre></div>
    }

    return <div className="text-center text-6xl mb-6">{question.visual}</div>;
};

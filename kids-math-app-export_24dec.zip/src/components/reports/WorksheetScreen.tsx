import React, { useState, useEffect } from 'react';
import { ArrowLeft, FileText, Download, Check, AlertCircle } from 'lucide-react';
import { Kid, Worksheet } from '../../types';
import { db } from '../../services/db';
import { generateWorksheet } from '../../utils/worksheetGenerator';

interface WorksheetScreenProps {
    kid: Kid;
    onBack: () => void;
}

export const WorksheetScreen: React.FC<WorksheetScreenProps> = ({ kid, onBack }) => {
    const [worksheets, setWorksheets] = useState<Worksheet[]>([]);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        loadWorksheets();
    }, [kid.id]);

    const loadWorksheets = () => {
        const list = db.getWorksheets(kid.id);
        setWorksheets(list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
    };

    const handleGenerate = async () => {
        setGenerating(true);
        setError('');

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1500));

        const count = db.getErrors(kid.id, 7).length;
        if (count < 3) {
            setError('Not enough recent practice data to generate a focused worksheet. Encourage your child to play more levels!');
            setGenerating(false);
            return;
        }

        const ws = await generateWorksheet(kid.id);
        if (ws) {
            loadWorksheets();
        } else {
            setError('Could not generate worksheet. Try again later.');
        }
        setGenerating(false);
    };

    return (
        <div className="fixed inset-0 bg-gray-50 z-50 overflow-y-auto">
            <div className="bg-white shadow">
                <div className="container mx-auto px-4 py-4 max-w-4xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={onBack}
                            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                        >
                            <ArrowLeft className="w-6 h-6 text-gray-600" />
                        </button>
                        <h1 className="text-xl font-bold text-gray-800">Practice Worksheets: {kid.name}</h1>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 py-8 max-w-4xl">
                <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-2xl p-8 text-white mb-8">
                    <div className="flex items-start justify-between">
                        <div>
                            <h2 className="text-2xl font-bold mb-2">Personalized Practice</h2>
                            <p className="text-purple-100 mb-6 max-w-lg">
                                Generate custom PDF worksheets based on the mistakes {kid.name} has made recently.
                                Focus on weak spots to improve mastery.
                            </p>
                            <button
                                onClick={handleGenerate}
                                disabled={generating}
                                className="bg-white text-purple-600 px-6 py-3 rounded-xl font-bold hover:shadow-lg transition-all flex items-center gap-2 disabled:opacity-75"
                            >
                                {generating ? (
                                    <>Processing...</>
                                ) : (
                                    <>
                                        <FileText className="w-5 h-5" />
                                        Generate New Worksheet
                                    </>
                                )}
                            </button>
                        </div>
                        <FileText className="w-32 h-32 text-white opacity-20" />
                    </div>

                    {error && (
                        <div className="mt-6 bg-white bg-opacity-10 rounded-lg p-4 flex items-start gap-3">
                            <AlertCircle className="w-5 h-5 text-yellow-300 flex-shrink-0 mt-0.5" />
                            <p className="text-sm font-medium">{error}</p>
                        </div>
                    )}
                </div>

                <div className="space-y-4">
                    <h3 className="text-lg font-bold text-gray-800 mb-4">Past Worksheets</h3>

                    {worksheets.length === 0 ? (
                        <div className="text-center py-12 text-gray-500 bg-white rounded-xl border border-gray-100">
                            No worksheets generated yet.
                        </div>
                    ) : (
                        worksheets.map(ws => (
                            <div key={ws.id} className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center justify-between">
                                <div>
                                    <div className="flex items-center gap-3 mb-1">
                                        <h4 className="font-bold text-gray-800">Practice Set {new Date(ws.created_at).toLocaleDateString()}</h4>
                                        <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-bold">Ready</span>
                                    </div>
                                    <p className="text-sm text-gray-500 mb-3">
                                        Focus: {ws.focus_areas.map(([area, count]) => `${area.replace('_error', '')} (${count})`).join(', ')}
                                    </p>
                                    <div className="text-xs text-gray-400">
                                        ID: {ws.id}
                                    </div>
                                </div>

                                <button
                                    className="p-3 bg-gray-50 text-gray-600 rounded-lg hover:bg-purple-50 hover:text-purple-600 transition-colors"
                                    aria-label="Download PDF"
                                    onClick={() => alert('In a real app, this would download the PDF!')}
                                >
                                    <Download className="w-6 h-6" />
                                </button>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

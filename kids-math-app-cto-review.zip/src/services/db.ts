import { DBState, User, Kid, ProgressLog, ErrorLog, Worksheet } from '../types';
import { StorageAdapter } from '../types';
import { LocalStorageAdapter } from './storage';

class DatabaseService {
    private db: DBState;
    private storage: StorageAdapter;
    private STORAGE_KEY = 'kidsAppDB';

    constructor(storage: StorageAdapter) {
        this.storage = storage;
        this.db = {
            users: [],
            kids: [],
            progress: [],
            errors: [],
            worksheets: [],
            offlineQueue: [],
            session: null
        };
    }

    init() {
        const stored = this.storage.get(this.STORAGE_KEY);
        if (stored) {
            // Merge stored data ensuring all keys exist
            this.db = { ...this.db, ...stored };
        }
    }

    save() {
        this.storage.set(this.STORAGE_KEY, this.db);
    }

    // Auth
    createUser(email: string, password: string, firstName: string, surname: string, parentAge: string): User {
        const user: User = {
            id: `user_${Date.now()}`,
            email,
            password,
            firstName,
            surname,
            parentAge,
            role: 'parent',
            created_at: new Date().toISOString()
        };
        this.db.users.push(user);
        this.save();
        return user;
    }

    login(email: string, password: string): User | null {
        const user = this.db.users.find(u => u.email === email && u.password === password);
        if (user) {
            this.db.session = { userId: user.id, email: user.email };
            this.save();
            return user;
        }
        return null;
    }

    logout() {
        this.db.session = null;
        this.save();
    }

    getSession() {
        return this.db.session;
    }

    getUser(userId: string) {
        return this.db.users.find(u => u.id === userId);
    }

    // Kid Profiles
    createKid(userId: string, name: string, age: number, avatar: string): Kid {
        const kid: Kid = {
            id: `kid_${Date.now()}`,
            user_id: userId,
            name,
            age,
            avatar,
            created_at: new Date().toISOString(),
            difficulty_index: 1,
            streak: 0,
            last_play_date: null,
            coins: 0,
            total_coins_earned: 0,
            unlocked_avatars: ['🦁'],
            daily_questions_today: 0,
            last_question_date: null,
            session_time_today: 0,
            achievements: []
        };
        this.db.kids.push(kid);
        this.save();
        return kid;
    }

    getKidsByUser(userId: string) {
        return this.db.kids.filter(k => k.user_id === userId);
    }

    getKid(kidId: string) {
        return this.db.kids.find(k => k.id === kidId);
    }

    // Progress & Game Logic
    addCoins(kidId: string, amount: number) {
        const kid = this.getKid(kidId);
        if (kid) {
            kid.coins += amount;
            kid.total_coins_earned += amount;
            this.save();
        }
    }

    canPlayToday(kid: Kid) {
        const today = new Date().toDateString();
        const lastPlayDate = kid.last_question_date ? new Date(kid.last_question_date).toDateString() : null;

        if (lastPlayDate !== today) {
            kid.daily_questions_today = 0;
            kid.session_time_today = 0;
            kid.last_question_date = new Date().toISOString();
            this.save();
            return { canPlay: true, questionsLeft: 100, timeLeft: 900 };
        }

        const questionsLeft = 100 - kid.daily_questions_today;
        const timeLeft = 900 - kid.session_time_today;

        return {
            canPlay: questionsLeft > 0 && timeLeft > 0,
            questionsLeft,
            timeLeft
        };
    }

    updateDailyUsage(kidId: string, questionsAnswered: number, timeSpent: number) {
        const kid = this.getKid(kidId);
        if (kid) {
            kid.daily_questions_today += questionsAnswered;
            kid.session_time_today += timeSpent;
            this.save();
        }
    }

    logLevelStart(kidId: string, trackId: string, levelId: number) {
        const entry: ProgressLog = {
            kid_id: kidId,
            track_id: trackId,
            level_id: levelId,
            status: 'started',
            started_at: new Date().toISOString(),
            attempts: 1,
            score: 0,
            time_spent_seconds: 0
        };
        this.db.progress.push(entry);
        this.save();
        return entry;
    }

    logLevelComplete(kidId: string, trackId: string, levelId: number, score: number, timeSpent: number) {
        const entry = this.db.progress.find(p => p.kid_id === kidId && p.track_id === trackId && p.level_id === levelId && p.status === 'started');
        if (entry) {
            entry.status = 'completed';
            entry.completed_at = new Date().toISOString();
            entry.score = score;
            entry.time_spent_seconds = timeSpent;

            const kid = this.getKid(kidId);
            if (kid) {
                const today = new Date().toDateString();
                const lastPlay = kid.last_play_date ? new Date(kid.last_play_date).toDateString() : null;

                if (lastPlay !== today) {
                    const yesterday = new Date(Date.now() - 86400000).toDateString();
                    kid.streak = lastPlay === yesterday ? kid.streak + 1 : 1;
                    kid.last_play_date = new Date().toISOString();
                }
            }
            this.save();
        }
    }

    logError(kidId: string, trackId: string, levelId: number, errorType: string, difficulty: number, mode: string) {
        const error: ErrorLog = {
            kid_id: kidId,
            track_id: trackId,
            level_id: levelId,
            error_type: errorType,
            difficulty_index: difficulty,
            mode,
            created_at: new Date().toISOString(),
            offline_flag: false
        };
        this.db.errors.push(error);
        this.save();
    }

    getCompletedProgress(kidId: string) {
        return this.db.progress.filter(p => p.kid_id === kidId && p.status === 'completed');
    }

    getErrors(kidId: string, daysBack = 7) {
        if (daysBack === -1) return this.db.errors.filter(e => e.kid_id === kidId);

        const cutoff = new Date(Date.now() - daysBack * 86400000);
        return this.db.errors.filter(e =>
            e.kid_id === kidId && new Date(e.created_at) > cutoff
        );
    }

    // Worksheets
    addWorksheet(worksheet: Worksheet) {
        this.db.worksheets.push(worksheet);
        this.save();
    }

    getWorksheets(kidId: string) {
        return this.db.worksheets.filter(w => w.kid_id === kidId);
    }
}

// Singleton export
export const db = new DatabaseService(new LocalStorageAdapter());

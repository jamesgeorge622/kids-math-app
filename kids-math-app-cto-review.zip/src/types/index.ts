export interface User {
    id: string;
    email: string;
    password?: string; // In a real app, this wouldn't be on the client
    firstName: string;
    surname: string;
    parentAge: string;
    role: 'parent' | 'admin';
    created_at: string;
}

export interface Kid {
    id: string;
    user_id: string;
    name: string;
    age: number;
    avatar: string;
    created_at: string;
    difficulty_index: number;
    streak: number;
    last_play_date: string | null;
    coins: number;
    total_coins_earned: number;
    unlocked_avatars: string[];
    daily_questions_today: number;
    last_question_date: string | null;
    session_time_today: number;
    achievements: string[];
}

export interface ProgressLog {
    kid_id: string;
    track_id: string;
    level_id: number;
    status: 'started' | 'completed';
    started_at: string;
    completed_at?: string;
    attempts: number;
    score: number;
    time_spent_seconds: number;
}

export interface ErrorLog {
    kid_id: string;
    track_id: string;
    level_id: number;
    error_type: string;
    difficulty_index: number;
    mode: string;
    created_at: string;
    offline_flag: boolean;
}

export interface Worksheet {
    id: string;
    kid_id: string;
    period_start: string;
    period_end: string;
    status: 'generated' | 'completed';
    focus_areas: [string, number][]; // [ErrorType, Count]
    created_at: string;
    pdf_url: string;
}

export interface MathTrack {
    id: string;
    title: string;
    description: string;
    icon: string;
    color: string;
    ageRange: [number, number];
    levels: number;
    concepts: string[];
}

export interface ExplanationStep {
    visual?: string | any;
    steps: string[];
    tip?: string;
    intro?: string;
}

export interface Question {
    concept: string;
    question: string;
    visual: any;
    correctAnswer: any;
    options: any[];
    explanation: ExplanationStep;
}

export interface StorageAdapter {
    get(key: string): any;
    set(key: string, value: any): void;
    remove(key: string): void;
    clear(): void;
}

export interface DBState {
    users: User[];
    kids: Kid[];
    progress: ProgressLog[];
    errors: ErrorLog[];
    worksheets: Worksheet[];
    offlineQueue: any[];
    session: { userId: string; email: string } | null;
}

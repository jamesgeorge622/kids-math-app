import { useState, useEffect } from 'react';
import { FractionVisual } from './visuals/FractionVisual';
import { DivisionVisual } from './visuals/DivisionVisual';
import { DecimalVisual } from './visuals/DecimalVisual';
import { PercentageVisual } from './visuals/PercentageVisual';
import { WordProblemVisual } from './visuals/WordProblemVisual';
import { CountingVisual } from './visuals/CountingVisual';
import { AdditionVisual } from './visuals/AdditionVisual';
import { MultiplicationVisual } from './visuals/MultiplicationVisual';
import { NumberBondVisual } from './visuals/NumberBondVisual';
import { DataVisual } from './visuals/DataVisual';
import { SubtractionVisual } from './visuals/SubtractionVisual';
import { TimeVisual } from './visuals/TimeVisual';
import { PlaceValueVisual } from './visuals/PlaceValueVisual';
import { SequenceVisual } from './visuals/SequenceVisual';
import { ShapeVisual } from './visuals/ShapeVisual';
import { MoneyVisual } from './visuals/MoneyVisual';
import { ComparisonVisual } from './visuals/ComparisonVisual';
import { MeasurementVisual } from './visuals/MeasurementVisual';

export const QuestionVisual = ({ question }: { question: any }) => {
    const [removedIndices, setRemovedIndices] = useState<Set<number>>(new Set());

    useEffect(() => {
        setRemovedIndices(new Set());
    }, [question]);

    const toggleRemoved = (index: number) => {
        const newSet = new Set(removedIndices);
        if (newSet.has(index)) {
            newSet.delete(index);
        } else {
            newSet.add(index);
        }
        setRemovedIndices(newSet);
    };

    switch (question.concept) {
        case 'fractions':
            return <FractionVisual question={question} />;
        case 'division':
            return <DivisionVisual question={question} />;
        case 'decimals':
            return <DecimalVisual question={question} />;
        case 'percentages':
            return <PercentageVisual question={question} />;
        case 'word_problems':
            return <WordProblemVisual question={question} />;
        case 'counting':
            return <CountingVisual question={question} />;
        case 'addition':
            return <AdditionVisual question={question} />;
        case 'multiplication':
            return <MultiplicationVisual question={question} />;
        case 'number_bonds':
            return <NumberBondVisual question={question} />;
        case 'data':
            return <DataVisual question={question} />;
        case 'subtraction':
            return (
                <SubtractionVisual
                    question={question}
                    removedIndices={removedIndices}
                    onToggle={toggleRemoved}
                />
            );
        case 'time':
            return <TimeVisual question={question} />;
        case 'place_value':
            return <PlaceValueVisual question={question} />;
        case 'algebra':
        case 'patterns':
        case 'skip_counting':
            return <SequenceVisual question={question} />;
        case 'shapes':
            return <ShapeVisual question={question} />;
        case 'money':
            return <MoneyVisual question={question} />;
        case 'comparison':
            return <ComparisonVisual question={question} />;
        case 'measurement':
            return <MeasurementVisual question={question} />;
        default:
            // Fallback handlers for simplified visuals or legacy arrays/objects
            if (Array.isArray(question.visual)) {
                return <div className="text-center text-4xl mb-6">{question.visual.join(' ')}</div>;
            }

            if (typeof question.visual === 'object' && question.visual !== null) {
                return <div className="text-center text-xl mb-6"><pre>{JSON.stringify(question.visual, null, 2)}</pre></div>
            }

            return <div className="text-center text-6xl mb-6">{question.visual}</div>;
    }
};

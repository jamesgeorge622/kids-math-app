

export const ShapeVisual = ({ question }: { question: any }) => {
    if (typeof question.visual === 'string') {
        const shape = question.visual.toLowerCase();
        return (
            <div className="flex justify-center mb-8">
                <div className={`
                    w-48 h-48 transition-all duration-500
                    ${shape.includes('circle') ? 'rounded-full bg-red-400' : ''}
                    ${shape.includes('square') ? 'bg-blue-400 rounded-lg' : ''}
                    ${shape.includes('rectangle') ? 'w-64 bg-green-400 rounded-lg' : ''}
                    ${shape.includes('triangle') ? 'w-0 h-0 border-l-[100px] border-l-transparent border-r-[100px] border-r-transparent border-b-[174px] border-b-yellow-400' : ''}
                    ${/* Fallback */ !['circle', 'square', 'rectangle', 'triangle'].some(s => shape.includes(s)) ? 'bg-purple-200 rounded-xl flex items-center justify-center' : ''}
                 `}>
                    {!['circle', 'square', 'rectangle', 'triangle'].some(s => shape.includes(s)) && (
                        <span className="text-2xl font-bold text-purple-700 capitalize">{shape}</span>
                    )}
                </div>
            </div>
        )
    }
    return null;
};

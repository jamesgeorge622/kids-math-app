

export const MeasurementVisual = ({ question }: { question: any }) => {
    const { unit, type, item } = question.visual;
    const isLength = ['inches', 'feet', 'yards'].includes(unit);
    const isWeight = ['ounces', 'pounds', 'tons'].includes(unit);

    // Object Estimation (e.g., Pencil length)
    if (type === 'object') {
        return (
            <div className="flex flex-col items-center mb-8">
                <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-indigo-100 max-w-md w-full relative overflow-hidden">
                    <div className="flex flex-col items-center gap-6">
                        {/* Object Visual */}
                        <div className="w-32 h-32 bg-blue-50 rounded-full flex items-center justify-center text-7xl shadow-inner mb-2 relative">
                            {item === 'pencil' && <span>✏️</span>}
                            {!item && <span>📏</span>}
                            {/* Dotted line indicating length */}
                            <div className="absolute -bottom-4 w-full flex justify-between text-xs text-gray-400 font-mono">
                                <span>|</span>
                                <span>? {unit}</span>
                                <span>|</span>
                            </div>
                        </div>

                        {/* Ruler Visual */}
                        <div className="w-full h-14 bg-yellow-300 border-2 border-yellow-500 rounded-md shadow-sm relative flex items-end overflow-hidden">
                            {[...Array(12)].map((_, i) => (
                                <div key={i} className="flex-1 h-3/4 border-r border-yellow-600/50 flex justify-end flex-col items-center">
                                    <div className="w-0.5 h-2 bg-yellow-700/40"></div>
                                    {i % 2 === 0 && <span className="text-[10px] text-yellow-800 font-bold mb-1">{i}</span>}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // Conversion Visual (Standard)
    return (
        <div className="flex flex-col items-center mb-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg border-2 border-indigo-100 max-w-md w-full relative overflow-hidden">
                {/* Background Pattern */}
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-400 to-purple-400"></div>

                <div className="flex flex-col items-center gap-6">
                    {/* Icon/Graphic Area */}
                    <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center text-6xl shadow-inner relative">
                        {isLength && <span className="transform -rotate-45">📏</span>}
                        {isWeight && <span>⚖️</span>}
                        {!isLength && !isWeight && <span>📏</span>}

                        {/* Decorative particles */}
                        <div className="absolute top-0 right-0 w-3 h-3 bg-yellow-400 rounded-full animate-ping opacity-75"></div>
                    </div>

                    {/* Conversion Visual */}
                    <div className="flex items-center gap-4 text-gray-700 font-bold text-xl md:text-2xl">
                        <div className="bg-gray-100 px-4 py-2 rounded-lg border border-gray-200">
                            1 {isLength ? (unit === 'inches' ? 'foot' : unit === 'feet' ? 'yard' : 'unit') : (unit === 'ounces' ? 'pound' : 'unit')}
                        </div>
                        <div className="text-indigo-400 text-3xl">➜</div>
                        <div className="bg-indigo-50 px-4 py-2 rounded-lg border border-indigo-200 text-indigo-700 flex items-center gap-2">
                            <span className="text-3xl">?</span>
                            <span className="text-lg opacity-70">{unit}</span>
                        </div>
                    </div>

                    {/* Visual Aid (Ruler or Scale hint) */}
                    {isLength && (
                        <div className="w-full h-12 bg-yellow-200 border-2 border-yellow-400 rounded-md relative mt-2 shadow-sm flex items-end overflow-hidden">
                            {[...Array(12)].map((_, i) => (
                                <div key={i} className="flex-1 h-1/2 border-r border-yellow-500/50 flex justify-end flex-col items-center">
                                    <div className="w-0.5 h-2 bg-yellow-600/30"></div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

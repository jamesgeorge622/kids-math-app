

export const PlaceValueVisual = ({ question }: { question: any }) => {
    if (question.visual.tens === undefined) return null;

    return (
        <div className="flex flex-col items-center mb-8">
            <div className="flex items-end gap-8 p-6 bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
                {/* Tens Group */}
                <div className="flex flex-col items-center gap-2">
                    <div className="flex gap-2">
                        {Array.from({ length: question.visual.tens }).map((_, i) => (
                            <div key={`ten-${i}`} className="w-4 h-32 bg-indigo-500 rounded-sm border border-indigo-600 flex flex-col justify-between py-1">
                                {/* Visual lines to look like a rod of 10 */}
                                {Array.from({ length: 9 }).map((_, j) => (
                                    <div key={j} className="h-px w-full bg-indigo-400/50" />
                                ))}
                            </div>
                        ))}
                    </div>
                    <span className="font-bold text-gray-500 text-sm uppercase tracking-wider">Tens ({question.visual.tens})</span>
                </div>

                {/* Ones Group */}
                <div className="flex flex-col items-center gap-2">
                    <div className="grid grid-cols-5 gap-1 content-end" style={{ height: '8rem' /* Match rod height broadly */ }}>
                        {Array.from({ length: question.visual.ones }).map((_, i) => (
                            <div key={`one-${i}`} className="w-4 h-4 bg-yellow-400 rounded-sm border border-yellow-500" />
                        ))}
                    </div>
                    <span className="font-bold text-gray-500 text-sm uppercase tracking-wider">Ones ({question.visual.ones})</span>
                </div>
            </div>
            <div className="mt-4 text-xl font-bold text-gray-700">
                {question.visual.tens} Tens + {question.visual.ones} Ones = ?
            </div>
        </div>
    );
};

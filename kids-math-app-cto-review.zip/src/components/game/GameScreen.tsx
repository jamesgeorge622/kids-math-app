import React, { useState, useEffect } from 'react';
import { ArrowRight, Lightbulb, ChevronDown } from 'lucide-react';
import { Kid, MathTrack } from '../../types';
import { generateQuestion } from '../../utils/questionGenerator';
import { db } from '../../services/db';
import { ExplanationScreen } from './ExplanationScreen';
import { CoinGuideModal } from './CoinGuideModal';
import { QuestionVisual } from './QuestionVisual';

interface GameScreenProps {
    kid: Kid;
    track: MathTrack;
    questionCount: number;
    onComplete: () => void;
    onResults: (results: { correct: number; total: number; timeSpent: number }) => void;
    onBack: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({ kid, track, questionCount, onComplete, onResults, onBack }) => {
    const [currentLevel, setCurrentLevel] = useState(1);
    const [question, setQuestion] = useState<any>(null);
    const [selectedAnswer, setSelectedAnswer] = useState<any>(null);
    const [gameState, setGameState] = useState<'loading' | 'playing' | 'correct' | 'incorrect'>('loading');
    const [startTime, setStartTime] = useState(Date.now());
    const [totalCorrect, setTotalCorrect] = useState(0);
    const [gameStartTime] = useState(Date.now());
    const [showExplanation, setShowExplanation] = useState(false);
    const [showHelp, setShowHelp] = useState(false);
    const [showCoinGuide, setShowCoinGuide] = useState(false);
    const [currency, setCurrency] = useState<'USD' | 'EUR'>('USD');
    const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);

    const mode = kid.age <= 7 ? 'A' : 'B';

    useEffect(() => {
        startNewQuestion();
    }, []);

    const startNewQuestion = (levelOverride?: number) => {
        const levelToUse = levelOverride ?? currentLevel;
        const newQuestion = generateQuestion(track.id, levelToUse, kid.difficulty_index, kid.age, currency);
        setQuestion(newQuestion);
        setGameState('playing');
        setSelectedAnswer(null);
        db.logLevelStart(kid.id, track.id, levelToUse);
        setStartTime(Date.now());
    };

    const handleAnswer = (answer: any) => {
        setSelectedAnswer(answer);

        if (answer === question.correctAnswer) {
            setGameState('correct');
            setTotalCorrect(prev => prev + 1);

            const timeSpent = Math.floor((Date.now() - startTime) / 1000);
            db.logLevelComplete(kid.id, track.id, currentLevel, 100, timeSpent);

            // Update coins
            db.addCoins(kid.id, 10);

            setTimeout(() => {
                if (currentLevel < questionCount) {
                    const nextLevel = currentLevel + 1;
                    setCurrentLevel(nextLevel);
                    startNewQuestion(nextLevel);
                } else {
                    // Game Over
                    const totalTimeSpent = Math.floor((Date.now() - gameStartTime) / 1000);
                    onResults({
                        correct: totalCorrect + 1, // +1 because state update is async/batched so we add current
                        total: questionCount,
                        timeSpent: totalTimeSpent
                    });
                    onComplete();
                }
            }, 2000);
        } else {
            setGameState('incorrect');
            db.logError(kid.id, track.id, currentLevel, `${question.concept}_error`, kid.difficulty_index, mode);

            // Show explanation after wrong answer
            setTimeout(() => {
                setShowExplanation(true);
            }, 1500);
        }
    };

    const handleTryAgain = () => {
        setShowExplanation(false);
        setGameState('playing');
        setSelectedAnswer(null);
    };

    const handleContinue = () => {
        setShowExplanation(false);
        if (currentLevel < questionCount) {
            const nextLevel = currentLevel + 1;
            setCurrentLevel(nextLevel);
            startNewQuestion(nextLevel);
        } else {
            const totalTimeSpent = Math.floor((Date.now() - gameStartTime) / 1000);
            onResults({
                correct: totalCorrect,
                total: questionCount,
                timeSpent: totalTimeSpent
            });
            onComplete();
        }
    };

    if (!question) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                <div className="text-white text-2xl font-bold">Loading...</div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex flex-col p-4">
            <div className="flex justify-between items-center mb-8">
                <button
                    onClick={onBack}
                    className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
                    aria-label="Exit Game"
                >
                    <ArrowRight className="w-6 h-6 text-gray-600 transform rotate-180" />
                </button>

                <div className="bg-white rounded-full px-6 py-2 shadow-lg">
                    <span className="font-bold text-gray-800">Question {currentLevel}/{questionCount}</span>
                </div>

                <div className="flex gap-2 relative">
                    {/* Currency Selector */}
                    {question?.concept === 'money' && (
                        <div className="relative">
                            <button
                                onClick={() => setShowCurrencyDropdown(!showCurrencyDropdown)}
                                className="bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors px-4 py-2 gap-2 border-2 border-indigo-100"
                                aria-label="Select Currency"
                            >
                                <span className="text-2xl">{currency === 'USD' ? '🇺🇸' : '🇪🇺'}</span>
                                <span className="font-bold text-gray-700 hidden sm:inline">{currency}</span>
                                <ChevronDown className="w-4 h-4 text-gray-400" />
                            </button>

                            {showCurrencyDropdown && (
                                <div className="absolute top-full mt-2 right-0 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-20 min-w-[120px] animate-fade-in">
                                    <button
                                        onClick={() => {
                                            if (currency !== 'USD') {
                                                setCurrency('USD');
                                                // Trigger new question with new currency immediately if desired, 
                                                // but for now let's just update preference for next question or simple re-gen
                                                // Ideally we should regenerate the question if we switch currency mid-game?
                                                // Let's do simple state update for now, user might need to click "Next" or we can force regen.
                                                // Let's force regen for immediate feedback.
                                                const newQ = generateQuestion(track.id, currentLevel, kid.difficulty_index, kid.age, 'USD');
                                                setQuestion(newQ);
                                            }
                                            setShowCurrencyDropdown(false);
                                        }}
                                        className="w-full px-4 py-3 flex items-center gap-3 hover:bg-blue-50 transition-colors text-left"
                                    >
                                        <span className="text-xl">🇺🇸</span>
                                        <span className="font-bold text-gray-700">USD</span>
                                    </button>
                                    <button
                                        onClick={() => {
                                            if (currency !== 'EUR') {
                                                setCurrency('EUR');
                                                const newQ = generateQuestion(track.id, currentLevel, kid.difficulty_index, kid.age, 'EUR');
                                                setQuestion(newQ);
                                            }
                                            setShowCurrencyDropdown(false);
                                        }}
                                        className="w-full px-4 py-3 flex items-center gap-3 hover:bg-blue-50 transition-colors text-left"
                                    >
                                        <span className="text-xl">🇪🇺</span>
                                        <span className="font-bold text-gray-700">EUR</span>
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                    {question.concept === 'money' && (
                        <button
                            onClick={() => setShowCoinGuide(true)}
                            className="bg-green-500 rounded-full shadow-lg flex items-center justify-center hover:scale-105 transition-transform px-4 py-2 gap-2 animate-bounce-subtle"
                            aria-label="Learn Money"
                        >
                            <span className="text-2xl">🪙</span>
                            <span className="text-white font-bold hidden sm:inline">Learn Money</span>
                        </button>
                    )}

                    <button
                        onClick={() => setShowHelp(true)}
                        className="bg-yellow-400 rounded-full shadow-lg flex items-center justify-center hover:bg-yellow-500 transition-colors px-4 py-2 gap-2"
                        aria-label="Help"
                    >
                        <Lightbulb className="w-6 h-6 text-white" />
                        <span className="text-white font-bold hidden sm:inline">Help</span>
                    </button>
                </div>
            </div>

            {/* Modals */}
            {showCoinGuide && <CoinGuideModal onClose={() => setShowCoinGuide(false)} currency={currency} />}

            <div className="flex-1 flex flex-col items-center justify-center">
                <div className="bg-white rounded-3xl p-8 shadow-2xl max-w-2xl w-full">
                    <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">
                        {question.question}
                    </h2>

                    <QuestionVisual question={question} />

                    {/* Answer Options */}
                    <div className="grid grid-cols-2 gap-4 mt-8">
                        {question.options.map((option: any, i: number) => (
                            <button
                                key={i}
                                onClick={() => handleAnswer(option)}
                                disabled={gameState !== 'playing'}
                                className={`h-24 rounded-2xl text-4xl font-bold transition-all transform hover:scale-105 active:scale-95 ${selectedAnswer === option
                                    ? gameState === 'correct'
                                        ? 'bg-green-500 text-white'
                                        : 'bg-red-500 text-white'
                                    : 'bg-gray-100 hover:bg-gray-200'
                                    } disabled:opacity-50`}
                            >
                                {question.concept === 'shapes' ? (
                                    <div className="flex justify-center items-center w-full h-full pointer-events-none">
                                        <div className={`
                                            transition-all duration-300 shadow-sm
                                            ${option === 'circle' ? 'w-16 h-16 rounded-full bg-red-400 border-4 border-red-500' : ''}
                                            ${option === 'square' ? 'w-16 h-16 rounded-xl bg-blue-400 border-4 border-blue-500' : ''}
                                            ${option === 'rectangle' ? 'w-24 h-12 rounded-xl bg-green-400 border-4 border-green-500' : ''}
                                            ${option === 'triangle' ? 'w-0 h-0 border-l-[32px] border-l-transparent border-r-[32px] border-r-transparent border-b-[56px] border-b-yellow-400 filter drop-shadow-sm' : ''}
                                        `} />
                                    </div>
                                ) : (
                                    option
                                )}
                            </button>
                        ))}
                    </div>

                    {/* Feedback */}
                    {gameState === 'correct' && (
                        <div className="mt-6 text-center">
                            <div className="text-6xl mb-2">🎉</div>
                            <p className="text-2xl font-bold text-green-600">Perfect!</p>
                        </div>
                    )}

                    {gameState === 'incorrect' && !showExplanation && (
                        <div className="mt-6 text-center">
                            <div className="text-6xl mb-2">🤔</div>
                            <p className="text-2xl font-bold text-orange-600">Not quite! Let me explain...</p>
                        </div>
                    )}
                </div>
            </div>



            {/* Explanation Modal */}
            {showExplanation && (
                <ExplanationScreen
                    question={question}
                    concept={question.concept}
                    mode={mode}
                    onTryAgain={handleTryAgain}
                    onContinue={handleContinue}
                />
            )}

            {/* Help Modal */}
            {showHelp && (
                <ExplanationScreen
                    question={question}
                    concept={question.concept}
                    mode={mode}
                    onTryAgain={() => setShowHelp(false)}
                    onContinue={() => setShowHelp(false)}
                    isHelpMode={true}
                />
            )}
        </div>
    );
};



import { db } from '../services/db';

export const getKidStats = (kidId: string) => {
    const completed = db.getCompletedProgress(kidId);
    const errors = db.getErrors(kidId, -1); // Get all errors

    // Calculate accuracy by track
    const trackStats: Record<string, { correct: number, total: number, timeSpent: number }> = {};

    completed.forEach(p => {
        if (!trackStats[p.track_id]) {
            trackStats[p.track_id] = { correct: 0, total: 0, timeSpent: 0 };
        }
        trackStats[p.track_id].total++;
        // Assuming score >= 80 is "correct" for the session level. 
        // Wait, original code said: if (p.score >= 80) trackStats[p.track_id].correct++;
        // But then totalQuestions was reduced from attempts...
        // Let's stick to original logic:

        // Original logic:
        // trackStats[p.track_id].total++;
        // if (p.score >= 80) trackStats[p.track_id].correct++;
        // trackStats[p.track_id].timeSpent += p.time_spent_seconds;

        if (p.score >= 80) {
            trackStats[p.track_id].correct++;
        }
        trackStats[p.track_id].timeSpent += p.time_spent_seconds;
    });

    const totalQuestions = completed.reduce((sum, p) => sum + (p.attempts || 1), 0);
    // Correct answers based on score? Original code: 
    // const correctAnswers = completed.reduce((sum, p) => sum + (p.score >= 100 ? 1 : 0), 0);
    // That seems weird if one session = 10 questions.
    // Actually the original code's "Progress" entry seems to map to a *Level* attempt, not a single question.
    // "logLevelComplete" sets score=100 if correct.
    // So yes, a "completed" entry with score 100 is 1 correct level?
    // But wait, `logLevelComplete` is called AFTER a question is answered correctly?
    // Original `handleAnswer`:
    // if correct: logLevelComplete(..., 100, timeSpent).
    // So yes, each entry in `progress` is actually a *Question* (or Level if 1 Q per Level?).
    // Original `GameScreen` increments `currentLevel` after correct answer.
    // So 1 Level = 1 Question in this app's logic.

    const correctAnswers = completed.length; // Since we only log 'completed' on 100 score?
    // completed = status === 'completed'.
    // In original code: setScore(score + 100); setGameState('correct'); logLevelComplete(..., 100, ...);
    // So yes, every completed log is a correct answer.

    // Wait, let's look at `getKidStats` original again.
    // const correctAnswers = completed.reduce((sum, p) => sum + (p.score >= 100 ? 1 : 0), 0);
    // If `logLevelComplete` is ALWAYS called with 100, then this is just `completed.length`.

    const overallAccuracy = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0;

    return {
        levelsCompleted: completed.length,
        totalErrors: errors.length,
        avgScore: completed.length > 0 ? Math.round(completed.reduce((sum, p) => sum + p.score, 0) / completed.length) : 0,
        totalPlayTime: completed.reduce((sum, p) => sum + p.time_spent_seconds, 0),
        trackStats,
        overallAccuracy,
        totalQuestions,
        correctAnswers
    };
};

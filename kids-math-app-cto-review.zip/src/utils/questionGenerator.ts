import { MATH_TRACKS } from '../data/tracks';
import { Question } from '../types';

export const generateQuestion = (trackId: string, level: number, difficulty: number, kidAge: number, currencyCode: 'USD' | 'EUR' = 'USD'): Question => {
    const track = MATH_TRACKS[trackId];
    if (!track || !track.concepts || track.concepts.length === 0) {
        return generateCountingQuestion(level, difficulty, kidAge);
    }

    const concept = track.concepts[0]; // Use primary concept

    switch (concept) {
        case 'counting':
            return generateCountingQuestion(level, difficulty, kidAge);
        case 'number_recognition':
            return generateNumberRecognitionQuestion(level, difficulty, kidAge);
        case 'shapes':
            return generateShapesQuestion(level, difficulty, kidAge);
        case 'colors':
            return generateColorsQuestion(level, difficulty, kidAge);
        case 'comparison':
            return generateComparisonQuestion(level, difficulty, kidAge);
        case 'addition':
            return generateAdditionQuestion(level, difficulty, kidAge);
        case 'subtraction':
            return generateSubtractionQuestion(level, difficulty, kidAge);
        case 'number_bonds':
            return generateNumberBondsQuestion(level, difficulty, kidAge);
        case 'skip_counting':
            return generateSkipCountingQuestion(level, difficulty, kidAge);
        case 'place_value':
            return generatePlaceValueQuestion(level, difficulty, kidAge);
        case 'time':
            return generateTimeQuestion(level, difficulty, kidAge);
        case 'multiplication':
            return generateMultiplicationQuestion(level, difficulty, kidAge);
        case 'division':
            return generateDivisionQuestion(level, difficulty, kidAge);
        case 'fractions':
            return generateFractionsQuestion(level, difficulty, kidAge);
        case 'decimals':
            return generateDecimalsQuestion(level, difficulty, kidAge);
        case 'percentages':
            return generatePercentagesQuestion(level, difficulty, kidAge);
        case 'word_problems':
            return generateWordProblemQuestion(level, difficulty, kidAge);
        case 'money':
            return generateMoneyQuestion(level, difficulty, kidAge, currencyCode);
        case 'measurement':
            return generateMeasurementQuestion(level, difficulty, kidAge);
        case 'data':
            return generateDataQuestion(level, difficulty, kidAge);
        case 'algebra':
            return generateAlgebraQuestion(level, difficulty, kidAge);
        default:
            return generateCountingQuestion(level, difficulty, kidAge);
    }
};

const generateCountingQuestion = (level: number, _difficulty: number, kidAge: number): Question => {
    const maxCount = kidAge === 5 ? Math.min(5 + level, 10) :
        kidAge === 6 ? Math.min(10 + level, 20) :
            Math.min(20 + level * 5, 100);
    const count = Math.floor(Math.random() * maxCount) + 1;
    const objects = ['🍎', '⭐', '🎈', '🐶', '🚗', '🏀', '🌸', '🦋', '🍪', '🎨'];
    const obj = objects[Math.floor(Math.random() * objects.length)];

    return {
        concept: 'counting',
        question: `How many ${obj} are there?`,
        visual: Array(count).fill(obj),
        correctAnswer: count,
        options: [count, count + 1, count - 1, count + 2].filter(n => n > 0).sort(() => Math.random() - 0.5),
        explanation: {
            visual: Array(count).fill(obj),
            steps: [
                'Let\'s count together!',
                'Point at each one as we count.',
                `Count: ${Array(count).fill(obj).map((_, i) => i + 1).join(', ')}`,
                `There are ${count} ${obj}!`
            ]
        }
    };
};

const generateNumberRecognitionQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const max = 10;
    const number = Math.floor(Math.random() * max) + 1;
    const objects = ['🔵', '⭐', '🎈'];
    const obj = objects[Math.floor(Math.random() * objects.length)];

    return {
        concept: 'number_recognition',
        question: `Which number matches these ${obj}?`,
        visual: Array(number).fill(obj),
        correctAnswer: number,
        options: [number, number + 1, number - 1, number + 2].filter(n => n > 0 && n <= 10).sort(() => Math.random() - 0.5),
        explanation: {
            visual: Array(number).fill(obj),
            steps: [
                `Let's count the ${obj}:`,
                `${Array(number).fill(obj).join(' ')}`,
                `We counted ${number} objects.`,
                `The number ${number} represents ${number} things!`
            ]
        }
    };
};

const generateShapesQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const shapes = [
        { name: 'circle', description: 'round like a ball' },
        { name: 'square', description: '4 equal sides' },
        { name: 'triangle', description: '3 sides' },
        { name: 'rectangle', description: '2 long sides, 2 short sides' }
    ];

    const targetShape = shapes[Math.floor(Math.random() * shapes.length)];
    const options = shapes.map(s => s.name);

    // Randomize "Find the X" vs "What shape is this?"
    // For now, let's stick to "Find the [Shape]" where options are visuals (handled in GameScreen)
    // OR "What shape is this?" where visual is shape and options are text.

    // Let's do "Find the [Shape]" as requested by user context "Find the square"

    return {
        concept: 'shapes',
        question: `Find the ${targetShape.name}!`,
        visual: targetShape.name, // Renders the target shape for "Find the..."
        correctAnswer: targetShape.name,
        options: options.sort(() => Math.random() - 0.5),
        explanation: {
            visual: targetShape.name, // Will trigger the CSS shape renderer in explanation
            steps: [
                `A ${targetShape.name} is ${targetShape.description}.`,
                `It looks like this!`,
                `Can you find a ${targetShape.name} around you?`
            ]
        }
    };
};

const generateColorsQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const colors = [
        { name: 'red', emoji: '🔴' },
        { name: 'blue', emoji: '🔵' },
        { name: 'yellow', emoji: '🟡' },
        { name: 'green', emoji: '🟢' }
    ];

    const targetColor = colors[Math.floor(Math.random() * colors.length)];
    const options = colors.map(c => c.emoji);

    return {
        concept: 'colors',
        question: `Which one is ${targetColor.name}?`,
        visual: options,
        correctAnswer: targetColor.emoji,
        options: options.sort(() => Math.random() - 0.5),
        explanation: {
            visual: [targetColor.emoji],
            steps: [
                `This is the color ${targetColor.name}: ${targetColor.emoji}`,
                `Colors help us describe things!`,
                `Can you find something ${targetColor.name} near you?`,
                `Learning colors is fun and useful!`
            ]
        }
    };
};

const generateComparisonQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const countA = Math.floor(Math.random() * 8) + 2;
    const countB = countA + Math.floor(Math.random() * 3) + 1;
    const obj = ['🍎', '⭐', '🎈'][Math.floor(Math.random() * 3)];

    return {
        concept: 'comparison',
        question: `Which group has MORE ${obj}?`,
        visual: {
            groupA: Array(countA).fill(obj),
            groupB: Array(countB).fill(obj)
        },
        correctAnswer: 'Group B',
        options: ['Group A', 'Group B'].sort(() => Math.random() - 0.5),
        explanation: {
            visual: {
                groupA: Array(countA).fill(obj),
                groupB: Array(countB).fill(obj)
            },
            steps: [
                `Group A has ${countA} ${obj}`,
                `Group B has ${countB} ${obj}`,
                `${countB} is MORE than ${countA}`,
                `Group B has MORE!`
            ]
        }
    };
};

const generateAdditionQuestion = (level: number, _difficulty: number, kidAge: number): Question => {
    // Difficulty scaling:
    // Age 5: max num 5 (Total ~10) - Very Easy
    // Age 6-7: max num 10 (Total ~20) - Easy
    // Age 8-9: max num 30 (Total ~60) - Medium
    // Age 10+: max num 50 (Total ~100) - Medium Harder
    let max = 50;
    if (kidAge <= 5) max = 5;
    else if (kidAge <= 7) max = 10;
    else if (kidAge <= 9) max = 30;

    // Add level buffer but cap at sensible limits per age
    const effectiveMax = Math.min(max + (level * 2), kidAge >= 10 ? 100 : max * 1.5);

    const a = Math.floor(Math.random() * effectiveMax) + 1;
    const b = Math.floor(Math.random() * effectiveMax) + 1;
    const answer = a + b;
    const isVertical = kidAge >= 10;

    return {
        concept: 'addition',
        question: `What is ${a} + ${b}?`,
        visual: {
            groupA: isVertical ? [] : Array(a).fill('🔵'),
            groupB: isVertical ? [] : Array(b).fill('🔵'),
            valA: a,
            valB: b,
            isVertical
        },
        correctAnswer: answer,
        options: [answer, answer + 1, answer - 1, answer + 2].filter(n => n > 0).sort(() => Math.random() - 0.5),
        explanation: {
            visual: {
                groupA: isVertical ? [] : Array(a).fill('🔵'),
                groupB: isVertical ? [] : Array(b).fill('🔵'),
                combined: isVertical ? [] : Array(answer).fill('🔵'),
                valA: a,
                valB: b,
                isVertical
            },
            steps: isVertical ? [
                `1. Stack the numbers: Ones over Ones, Tens over Tens.`,
                `2. Add the Ones column: ${a % 10} + ${b % 10} = ${(a % 10) + (b % 10)}`,
                ((a % 10) + (b % 10) >= 10) ? `   (Don't forget to carry the 10!)` : null,
                `3. Add the Tens column: ${Math.floor(a / 10)}0 + ${Math.floor(b / 10)}0 = ${Math.floor(answer / 10)}0`,
                `4. Total: ${answer}`
            ].filter(Boolean) as string[] : [
                `Start with ${a}`,
                `Add ${b} more`,
                `${a} + ${b} = ${answer}!`
            ]
        }
    };
};

const generateSubtractionQuestion = (level: number, _difficulty: number, kidAge: number): Question => {
    // Difficulty scaling:
    // Age 5: max start 10 - Very Easy
    // Age 6-7: max start 20 - Easy
    // Age 8-9: max start 50 - Medium
    // Age 10+: max start 100 - Medium Harder
    let max = 100;
    if (kidAge <= 5) max = 10;
    else if (kidAge <= 7) max = 20;
    else if (kidAge <= 9) max = 50;

    const effectiveMax = Math.min(max + (level * 2), kidAge >= 10 ? 150 : max * 1.2);

    const a = Math.floor(Math.random() * effectiveMax) + 3; // Ensure at least 3 to allow subtraction
    const b = Math.floor(Math.random() * (a - 1)) + 1;      // Ensure result > 0
    const answer = a - b;
    const isVertical = kidAge >= 10;

    return {
        concept: 'subtraction',
        question: `What is ${a} - ${b}?`,
        visual: {
            start: isVertical ? [] : Array(a).fill('⭐'),
            takeAway: b,
            valA: a,
            valB: b,
            isVertical
        },
        correctAnswer: answer,
        options: [answer, answer + 1, answer - 1, answer + 2].filter(n => n >= 0).sort(() => Math.random() - 0.5),
        explanation: {
            visual: {
                start: isVertical ? [] : Array(a).fill('⭐'),
                removed: isVertical ? [] : Array(b).fill('❌'),
                remaining: isVertical ? [] : Array(answer).fill('⭐'),
                valA: a,
                valB: b,
                isVertical
            },
            steps: isVertical ? [
                `1. Stack the numbers correctly.`,
                `2. Subtract the Ones: ${a % 10} - ${b % 10} = ?`,
                (a % 10 < b % 10) ? `   (You can't do ${a % 10} - ${b % 10}, so borrow 10 from the Tens column!)` : `   ${a % 10} - ${b % 10} = ${(a % 10) - (b % 10)}`,
                `3. Subtract the Tens: ${(a % 10 < b % 10) ? Math.floor(a / 10) - 1 : Math.floor(a / 10)}0 - ${Math.floor(b / 10)}0`,
                `4. Answer: ${answer}`
            ].filter(Boolean) as string[] : [
                `Start with ${a}`,
                `Take away ${b}`,
                `${a} - ${b} = ${answer}!`
            ]
        }
    };
};

const generateNumberBondsQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const total = Math.floor(Math.random() * 5) + 5; // 5-10
    const part1 = Math.floor(Math.random() * (total - 1)) + 1;
    const part2 = total - part1;

    return {
        concept: 'number_bonds',
        question: `${total} = ${part1} + ?`,
        visual: {
            total: Array(total).fill('🔵'),
            part1: Array(part1).fill('🔵'),
            part2: part2
        },
        correctAnswer: part2,
        options: [part2, part2 + 1, part2 - 1, part2 + 2].filter(n => n > 0).sort(() => Math.random() - 0.5),
        explanation: {
            visual: {
                total: Array(total).fill('🔵'),
                split: [Array(part1).fill('🔵'), Array(part2).fill('🔵')]
            },
            steps: [
                `${total} can be split into ${part1} and ${part2}`,
                `${part1} + ${part2} = ${total}`,
                `So ${total} = ${part1} + ${part2}!`,
                `Number bonds help you see how numbers fit together!`
            ]
        }
    };
};

const generateSkipCountingQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const skipBy = [2, 5, 10][Math.floor(Math.random() * 3)];
    const start = skipBy;
    const length = 4;
    const sequence = Array(length).fill(0).map((_, i) => start + (i * skipBy));

    return {
        concept: 'skip_counting',
        question: `Count by ${skipBy}s. What comes next after ${sequence[length - 2]}?`,
        visual: sequence.slice(0, -1).map(n => `${n}`),
        correctAnswer: sequence[length - 1],
        options: [sequence[length - 1], sequence[length - 1] + 1, sequence[length - 1] + skipBy, sequence[length - 1] - skipBy].sort(() => Math.random() - 0.5),
        explanation: {
            visual: sequence.map(n => `${n}`),
            steps: [
                `When we count by ${skipBy}s, we add ${skipBy} each time.`,
                `${sequence.join(', ')}`,
                `${sequence[length - 2]} + ${skipBy} = ${sequence[length - 1]}`,
                `The next number is ${sequence[length - 1]}!`
            ]
        }
    };
};

const generatePlaceValueQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const tens = Math.floor(Math.random() * 9) + 1;
    const ones = Math.floor(Math.random() * 10);
    const number = tens * 10 + ones;

    // Generate unique options
    const optionsSet = new Set<number>();
    optionsSet.add(tens);
    optionsSet.add(tens + 1);
    optionsSet.add(tens - 1);
    if (ones !== tens) optionsSet.add(ones);

    // Fill with randoms if needed
    while (optionsSet.size < 4) {
        optionsSet.add(Math.floor(Math.random() * 10) + 1);
    }

    const options = Array.from(optionsSet).slice(0, 4).sort(() => Math.random() - 0.5);

    return {
        concept: 'place_value',
        question: `How many tens are in ${number}?`,
        visual: { number, tens, ones },
        correctAnswer: tens,
        options: options,
        explanation: {
            visual: { number, tens, ones },
            steps: [
                `${number} has two digits.`,
                `The ${tens} is in the tens place = ${tens * 10}`,
                `The ${ones} is in the ones place = ${ones}`,
                `${number} = ${tens} tens + ${ones} ones = ${tens * 10} + ${ones}`
            ]
        }
    };
};

const generateTimeQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const hour = Math.floor(Math.random() * 12) + 1;
    const minute = [0, 15, 30, 45][Math.floor(Math.random() * 4)];
    const timeStr = minute === 0 ? `${hour}:00` : `${hour}:${minute}`;

    return {
        concept: 'time',
        question: `What time is shown?`,
        visual: { hour, minute, display: `🕐 ${timeStr}` },
        correctAnswer: timeStr,
        options: [timeStr, `${hour + 1}:00`, `${hour}:${minute + 15}`, `${hour - 1}:30`].sort(() => Math.random() - 0.5),
        explanation: {
            visual: { display: `🕐 ${timeStr}` },
            steps: [
                `The short hand points to the hour: ${hour}`,
                minute === 0 ? 'The long hand points to 12: that means :00' : `The long hand shows minutes: ${minute}`,
                `The time is ${timeStr}`,
                `Practice reading clocks at home!`
            ]
        }
    };
};

const generateMultiplicationQuestion = (level: number, _difficulty: number, kidAge: number): Question => {
    const maxFactor = kidAge <= 8 ? 5 : kidAge <= 9 ? 10 : 12;
    const a = Math.floor(Math.random() * Math.min(maxFactor, 2 + level)) + 2;
    const b = Math.floor(Math.random() * Math.min(maxFactor, 2 + level)) + 2;
    const answer = a * b;

    return {
        concept: 'multiplication',
        question: `What is ${a} × ${b}?`,
        visual: {
            groups: a,
            perGroup: b
        },
        correctAnswer: answer,
        options: [answer, answer + a, answer - a, answer + b].sort(() => Math.random() - 0.5),
        explanation: {
            visual: {
                groups: Array(a).fill(null).map(() => Array(b).fill('🔷'))
            },
            steps: [
                `${a} × ${b} means "${a} groups of ${b}"`,
                `Let's count each group:`,
                ...Array(a).fill(null).map((_, i) => `Group ${i + 1}: ${Array(b).fill('🔷').join(' ')}`),
                `That's ${b} ` + `+ ${b} `.repeat(a - 2) + `+ ${b} = ${answer}`,
                `So ${a} × ${b} = ${answer}!`
            ]
        }
    };
};

const generateDivisionQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const divisor = Math.floor(Math.random() * 5) + 2;
    const quotient = Math.floor(Math.random() * 8) + 2;
    const dividend = divisor * quotient;

    const wrongOptionsSet = new Set<number>();
    while (wrongOptionsSet.size < 3) {
        const offset = Math.floor(Math.random() * 5) - 2;
        const val = quotient + offset;
        if (val > 0 && val !== quotient) {
            wrongOptionsSet.add(val);
        } else {
            const randomVal = Math.floor(Math.random() * 10) + 1;
            if (randomVal !== quotient) wrongOptionsSet.add(randomVal);
        }
    }
    const wrongOptions = Array.from(wrongOptionsSet);

    return {
        concept: 'division',
        question: `What is ${dividend} ÷ ${divisor}?`,
        visual: {
            total: dividend,
            groups: divisor
        },
        correctAnswer: quotient,
        options: [quotient, ...wrongOptions].sort(() => Math.random() - 0.5),
        explanation: {
            visual: {
                total: Array(dividend).fill('🔵'),
                groups: Array(divisor).fill(null).map(() => Array(quotient).fill('🔵'))
            },
            steps: [
                `${dividend} ÷ ${divisor} means "split ${dividend} into ${divisor} equal groups"`,
                `Let's share ${dividend} objects into ${divisor} groups:`,
                `Each group gets ${quotient} objects!`,
                `${dividend} ÷ ${divisor} = ${quotient}`
            ]
        }
    };
};

const generateFractionsQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const fractions = [
        { display: '1/2', value: 0.5, name: 'one half', theme: 'pizza', total: 2, filled: 1 },
        { display: '1/2', value: 0.5, name: 'one half', theme: 'chocolate', total: 2, filled: 1 },
        { display: '1/4', value: 0.25, name: 'one quarter', theme: 'pizza', total: 4, filled: 1 },
        { display: '1/4', value: 0.25, name: 'one quarter', theme: 'chocolate', total: 4, filled: 1 },
        { display: '3/4', value: 0.75, name: 'three quarters', theme: 'pizza', total: 4, filled: 3 },
        { display: '3/4', value: 0.75, name: 'three quarters', theme: 'chocolate', total: 4, filled: 3 },
        { display: '1/3', value: 0.33, name: 'one third', theme: 'pizza', total: 3, filled: 1 },
        { display: '2/3', value: 0.67, name: 'two thirds', theme: 'pizza', total: 3, filled: 2 },
        { display: '1/5', value: 0.2, name: 'one fifth', theme: 'chocolate', total: 5, filled: 1 }, // vertical bar
        { display: '2/5', value: 0.4, name: 'two fifths', theme: 'chocolate', total: 5, filled: 2 },
        { display: '3/5', value: 0.6, name: 'three fifths', theme: 'chocolate', total: 5, filled: 3 }
    ];

    // Pick a random fraction from the list
    // Use simple random selection to avoid repeating the same sequence based on level
    const index = Math.floor(Math.random() * fractions.length);
    const fraction = fractions[index];

    // Visual is now an object describing the food item
    const visualData = {
        type: 'fraction',
        theme: fraction.theme,
        total: fraction.total,
        filled: fraction.filled
    };

    const visualString = Array(fraction.total).fill('').map((_, i) => i < fraction.filled ? '🟦' : '⬜').join('');

    // Generate options
    // 1. Get all unique display values (e.g. '1/2', '1/4') avoiding duplicates from different themes
    const uniqueDisplays = Array.from(new Set(fractions.map(f => f.display)));

    // 2. Filter out the correct answer
    const wrongOptionsPool = uniqueDisplays.filter(display => display !== fraction.display);

    // 3. Shuffle and slice to get 3 wrong options
    const wrongOptions = wrongOptionsPool
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);

    const allOptions = [fraction.display, ...wrongOptions].sort(() => Math.random() - 0.5);

    return {
        concept: 'fractions',
        question: `Which shows ${fraction.name}?`,
        visual: visualData, // Send the object for the GameScreen to render
        correctAnswer: fraction.display,
        options: allOptions,
        explanation: {
            visual: visualString, // Keep simple string for explanation modal for now
            steps: [
                `${fraction.display} means ${fraction.name}`,
                `We have ${fraction.total} equal pieces total (bottom number)`,
                `${fraction.filled} piece${fraction.filled > 1 ? 's' : ''} ${fraction.filled > 1 ? 'are' : 'is'} filled (top number)`,
                `So the fraction is ${fraction.filled}/${fraction.total}`
            ]
        }
    };
};

const generateDecimalsQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const whole = Math.floor(Math.random() * 5);
    const decimal = [0, 0.25, 0.5, 0.75][Math.floor(Math.random() * 4)];
    const number = whole + decimal;

    return {
        concept: 'decimals',
        question: `What is ${number} as a decimal?`,
        visual: { number: number.toString() },
        correctAnswer: number,
        options: [number, number + 0.5, number + 1, number - 0.5].filter(n => n >= 0).sort(() => Math.random() - 0.5),
        explanation: {
            visual: { number: number.toString() },
            steps: [
                `${number} is a decimal number`,
                `The number before the decimal point is ${whole}`,
                `The number after the decimal point is ${decimal}`,
                `Decimals help us show parts of a whole!`
            ]
        }
    };
};

const generatePercentagesQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const percentages = [25, 50, 75, 100];
    const percent = percentages[Math.floor(Math.random() * percentages.length)];
    const total = 100;
    const amount = (percent / 100) * total;

    // Generate unique wrong options
    const wrongOptionsSet = new Set<number>();
    while (wrongOptionsSet.size < 3) {
        const val = amount + (Math.floor(Math.random() * 5) - 2) * 10; // +/- 10, 20
        if (val > 0 && val !== amount) {
            wrongOptionsSet.add(val);
        } else {
            const randomVal = Math.floor(Math.random() * 10) * 10;
            if (randomVal !== amount && randomVal > 0) wrongOptionsSet.add(randomVal);
        }
    }
    const wrongOptions = Array.from(wrongOptionsSet);

    return {
        concept: 'percentages',
        question: `What is ${percent}% of ${total}?`,
        visual: { percent, total },
        correctAnswer: amount,
        options: [amount, ...wrongOptions].sort(() => Math.random() - 0.5),
        explanation: {
            visual: { percent, total, amount },
            steps: [
                `${percent}% means ${percent} out of 100`,
                `To find ${percent}% of ${total}:`,
                `${percent} ÷ 100 × ${total} = ${amount}`,
                `${percent}% of ${total} = ${amount}!`
            ]
        }
    };
};

const getRandomName = () => {
    const names = ['Sarah', 'Tom', 'Emma', 'Alex', 'Mike', 'Lisa', 'David', 'Amy', 'Ben', 'Zoe'];
    return names[Math.floor(Math.random() * names.length)];
};

const getRandomItem = (type: 'food' | 'toy' | 'book' | 'generic') => {
    const items = {
        food: ['apple', 'cookie', 'sweet', 'cupcake', 'pizza slice'],
        toy: ['toy car', 'ball', 'doll', 'robot', 'sticker'],
        book: ['book', 'comic', 'page'],
        generic: ['star', 'flower', 'shell']
    };
    return items[type][Math.floor(Math.random() * items[type].length)];
};

const generateWordProblemQuestion = (_level: number, _difficulty: number, kidAge: number): Question => {
    const scenario = Math.floor(Math.random() * 4);
    const name = getRandomName();
    const maxNumber = kidAge <= 6 ? 10 : 20;

    let question: any = {};

    switch (scenario) {
        case 0: { // Gave away
            const item = getRandomItem('food');
            const start = Math.floor(Math.random() * (maxNumber - 4)) + 4;
            const amount = Math.floor(Math.random() * (start - 1)) + 1;
            const left = start - amount;
            question = {
                story: `${name} has ${start} ${item}s. ${['Tom', 'Mike', 'David', 'Ben', 'Alex'].includes(name) ? 'He' : 'She'} gives ${amount} to a friend. How many ${item}s does ${name} have left?`,
                answer: left,
                visual: { start, action: "gave away", amount }
            };
            break;
        }
        case 1: { // Got more
            const item = getRandomItem('toy');
            const start = Math.floor(Math.random() * (maxNumber / 2)) + 1;
            const amount = Math.floor(Math.random() * (maxNumber / 2)) + 1;
            const total = start + amount;
            const pronoun = ['Tom', 'Mike', 'David', 'Ben', 'Alex'].includes(name) ? 'His' : 'Her';
            const objPronoun = ['Tom', 'Mike', 'David', 'Ben', 'Alex'].includes(name) ? 'him' : 'her';

            question = {
                story: `${name} has ${start} ${item}s. ${pronoun} mom buys ${objPronoun} ${amount} more. How many ${item}s does ${name} have now?`,
                answer: total,
                visual: { start, action: "got", amount }
            };
            break;
        }
        case 2: { // Share equally
            const item = getRandomItem('food');
            const groups = [2, 3, 4][Math.floor(Math.random() * 3)];
            const perGroup = Math.floor(Math.random() * 4) + 1;
            const total = groups * perGroup;
            question = {
                story: `There are ${total} ${item}s. ${groups} children share them equally. How many ${item}s does each child get?`,
                answer: perGroup,
                visual: { total, groups, action: "share equally" }
            };
            break;
        }
        case 3: { // Total over time
            const item = getRandomItem('book');
            const day1 = Math.floor(Math.random() * (maxNumber / 2)) + 1;
            const day2 = Math.floor(Math.random() * (maxNumber / 2)) + 1;
            const total = day1 + day2;
            const pronoun = ['Tom', 'Mike', 'David', 'Ben', 'Alex'].includes(name) ? 'he' : 'she';
            question = {
                story: `${name} reads ${day1} ${item}s on Monday and ${day2} ${item}s on Tuesday. How many ${item}s did ${pronoun} read in total?`,
                answer: total,
                visual: { day1, day2, action: "total" }
            };
            break;
        }
    }

    const wrongOptionsSet = new Set<number>();
    while (wrongOptionsSet.size < 3) {
        const offset = Math.floor(Math.random() * 5) - 2;
        const val = question.answer + offset;
        if (val > 0 && val !== question.answer) {
            wrongOptionsSet.add(val);
        } else {
            const randomVal = Math.floor(Math.random() * 10) + 1;
            if (randomVal !== question.answer) wrongOptionsSet.add(randomVal);
        }
    }
    const wrongOptions = Array.from(wrongOptionsSet);

    return {
        concept: 'word_problems',
        question: question.story,
        visual: question.visual,
        correctAnswer: question.answer,
        options: [question.answer, ...wrongOptions].sort(() => Math.random() - 0.5),
        explanation: {
            visual: question.visual,
            steps: [
                "Let's break down the problem:",
                `Key numbers: ${JSON.stringify(question.visual)}`,
                `The answer is ${question.answer}!`,
                "Always read carefully and find the important numbers!"
            ]
        }
    };
};

const generateMoneyQuestion = (_level: number, _difficulty: number, _kidAge: number, currencyCode: 'USD' | 'EUR' = 'USD'): Question => {
    const currencies: Record<'USD' | 'EUR', { code: 'USD' | 'EUR', symbol: string, coins: { name: string, value: number, emoji: string }[] }> = {
        'USD': {
            code: 'USD',
            symbol: '¢',
            coins: [
                { name: 'penny', value: 1, emoji: '🪙' },
                { name: 'nickel', value: 5, emoji: '🪙' },
                { name: 'dime', value: 10, emoji: '🪙' },
                { name: 'quarter', value: 25, emoji: '🪙' }
            ]
        },
        'EUR': {
            code: 'EUR',
            symbol: 'c',
            coins: [
                { name: '1 cent coin', value: 1, emoji: '🪙' },
                { name: '2 cent coin', value: 2, emoji: '🪙' },
                { name: '5 cent coin', value: 5, emoji: '🪙' },
                { name: '10 cent coin', value: 10, emoji: '🪙' },
                { name: '20 cent coin', value: 20, emoji: '🪙' },
                { name: '50 cent coin', value: 50, emoji: '🪙' }
            ]
        }
    };

    // Select currency
    const currency = currencies[currencyCode];
    const coin1 = currency.coins[Math.floor(Math.random() * currency.coins.length)];
    const count = Math.floor(Math.random() * 5) + 1;
    const total = coin1.value * count;

    // Helper to format money
    const formatMoney = (amount: number, code: 'USD' | 'EUR') => {
        if (code === 'USD') {
            if (amount >= 100) return `$${(amount / 100).toFixed(2)}`;
            return `${amount}¢`;
        } else {
            if (amount >= 100) return `€${(amount / 100).toFixed(2)}`;
            return `${amount}c`;
        }
    };

    // Format question appropriately
    const numberWords = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
    const countDisplay = count <= 10 ? numberWords[count] : count.toString();

    const questionText = currency.code === 'USD'
        ? `How much is ${countDisplay} ${coin1.name}${count > 1 ? 's' : ''}?`
        : `How much is ${countDisplay} ${coin1.name}${count > 1 ? 's' : ''}?`;

    const correctAnswerFormatted = formatMoney(total, currency.code);

    // Generate options first as numbers then format
    const numericOptions = [total, total + 5, total - 5, total + 10].filter(n => n > 0).sort(() => Math.random() - 0.5);
    // Ensure uniqueness
    const uniqueOptions = Array.from(new Set(numericOptions)).slice(0, 4);
    // If we filtered out too many negatives or duplicates, add some
    while (uniqueOptions.length < 4) {
        let newOpt = total + Math.floor(Math.random() * 20) - 10;
        if (newOpt > 0 && !uniqueOptions.includes(newOpt)) {
            uniqueOptions.push(newOpt);
        }
    }

    // Sort final numeric options relative to each other (optional, but good for cleanliness)
    uniqueOptions.sort((a, b) => a - b);
    // Wait, let's just shuffle them so answer position is random
    uniqueOptions.sort(() => Math.random() - 0.5);

    return {
        concept: 'money',
        question: questionText,
        visual: { coin: coin1.name, count, value: coin1.value, currency: currency.code },
        correctAnswer: correctAnswerFormatted, // Now returning string
        options: uniqueOptions.map(opt => formatMoney(opt, currency.code)), // Formatted strings
        explanation: {
            visual: Array(count).fill(coin1.emoji),
            steps: [
                `Each ${coin1.name} = ${formatMoney(coin1.value, currency.code)}`,
                `${count} ${coin1.name}${count > 1 ? 's' : ''} = ${count} × ${formatMoney(coin1.value, currency.code)}`,
                `${count} × ${coin1.value} = ${total}`,
                `Answer: ${correctAnswerFormatted}!`
            ]
        }
    };
};



const generateMeasurementQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const measurements = [
        { question: "How many inches in 1 foot?", answer: 12, unit: "inches", type: 'conversion' },
        { question: "How many feet in 1 yard?", answer: 3, unit: "feet", type: 'conversion' },
        { question: "How many ounces in 1 pound?", answer: 16, unit: "ounces", type: 'conversion' },
        { question: "A pencil is about how many inches long?", answer: 7, unit: "inches", type: 'object', item: 'pencil' }
    ];

    const m = measurements[Math.floor(Math.random() * measurements.length)];

    return {
        concept: 'measurement',
        question: m.question,
        visual: { unit: m.unit, answer: m.answer, type: m.type, item: m.item },
        correctAnswer: m.answer,
        options: [m.answer, m.answer + 1, m.answer - 1, m.answer + 2].filter(n => n > 0).sort(() => Math.random() - 0.5),
        explanation: {
            visual: { unit: m.unit },
            steps: [
                `The answer is ${m.answer} ${m.unit}`,
                "Measurement helps us compare sizes!",
                "Remember these common conversions.",
                "Practice measuring things at home!"
            ]
        }
    };
};

const generateDataQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const data: Record<string, number> = {
        apples: Math.floor(Math.random() * 10) + 1,
        oranges: Math.floor(Math.random() * 10) + 1,
        bananas: Math.floor(Math.random() * 10) + 1
    };

    const fruits = Object.keys(data);
    const targetFruit = fruits[Math.floor(Math.random() * fruits.length)];
    const answer = data[targetFruit];

    return {
        concept: 'data',
        question: `Look at the graph. How many ${targetFruit} are there?`,
        visual: data,
        correctAnswer: answer,
        options: [answer, answer + 1, answer - 1, data[fruits[0]]].filter((v, i, a) => a.indexOf(v) === i).sort(() => Math.random() - 0.5),
        explanation: {
            visual: data,
            steps: [
                `Look at the bar for ${targetFruit}`,
                `The bar reaches ${answer}`,
                `So there are ${answer} ${targetFruit}!`,
                "Always check the labels on graphs!"
            ]
        }
    };
};

const generateAlgebraQuestion = (_level: number, _difficulty: number, _kidAge: number): Question => {
    const start = Math.floor(Math.random() * 10) + 1;
    const step = Math.floor(Math.random() * 5) + 1;
    const length = 4;
    const sequence = Array(length).fill(0).map((_, i) => start + (i * step));
    const next = start + (length * step);

    return {
        concept: 'algebra',
        question: `What number comes next? ${sequence.join(', ')}, __`,
        visual: sequence,
        correctAnswer: next,
        options: [next, next + 1, next - 1, next + step].sort(() => Math.random() - 0.5),
        explanation: {
            visual: sequence,
            steps: [
                `Look at the pattern: ${sequence.join(', ')}`,
                `Each number increases by ${step}`,
                `${sequence[length - 1]} + ${step} = ${next}`,
                `The next number is ${next}!`
            ]
        }
    };
};
